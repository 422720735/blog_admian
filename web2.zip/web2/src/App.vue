<template>
    <router-view/>
</template>

<script>
    export default {
        name: 'App'
    }
</script>

<style lang="scss">@import "./assets/css/base.scss";</style>
