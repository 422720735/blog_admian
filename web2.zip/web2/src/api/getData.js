import axios from 'axios';
import router from '../router/index';

// const api = 'https://10.128.2.226';
// const api = '/api';
// const api = '';
const api = process.env.API_HOST;

// 链上信息记录
export const getChain = (data) => axios.get(api + '/web/raybaas/blocks', data);
// 链上文件类型
export const getType = (data) => axios.get(api + '/web/raybaas/files', data);
// 链上数据动态
export const getDt = (data) => axios.get(api + '/web/raybaas/status', data);
// 节点情况
export const getNodes = (data) => axios.get(api + '/web/raybaas/nodes', data);
// 资产信用评估模型
export const getAsserts = (data) => axios.get(api + '/web/raybaas/asserts', data);

// 链上数据物资图谱
export const getMaterials = (data) => axios.get(api + '/web/raybaas/materials', data);
// 链资产分段
export const getSubsection = (data) => axios.get(api + '/web/raybaas/subsection', data);


axios.defaults.withCredentials = true;
axios.defaults.headers.common['content-type'] = 'application/json;';
axios.interceptors.request.use(
    config => {
        // config.headers['Access-Control-Allow-Origin'] = '*';
        // config.headers['Access-Control-Allow-Headers'] = 'X-Requested-With,Content-Type';
        // config.headers['Access-Control-Allow-Methods'] = 'PUT,POST,GET,DELETE,OPTIONS';
        // console.info(sessionStorage.getItem('Authorization'))
        // if (sessionStorage.getItem('Authorization')) {
        //     config.headers.Authorization = sessionStorage.getItem('Authorization');
        // } else {
        //     router.push({path: '/login'});
        // }
        // config.withCredentials = true;
        // config.headers['web_url'] = location.href.split('?')[0];
        return config;
    },
    err => {
        return Promise.reject(err);
    });
//添加响应拦截器
axios.interceptors.response.use(
    response => {
        // if (response.data.code === 911) {
        //     router.push('/login');
        // }
        return response;
    },
    error => {
        return Promise.reject(error);
    });
