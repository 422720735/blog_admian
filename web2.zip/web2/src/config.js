/**
 * http://localhost:8080/#/main?ip=1&port=8001&userName=1212&passWord=123456
 *
 * 用户通过该地址可以访问不同域名下的配置项目
 *
 * 通过get传值 使用this.$route.query接收该值，如果传递使用传入的，没有传入就使用配置项的
 * */

// ip默认（默认不传）是外网的，如果传递的是1：青白江 2：金贸 或者其他
export const IP = {
    public: '171.221.225.163', // http://localhost:8080/#/main
    qbj: '10.0.200.100',       // http://localhost:8080/#/main?ip=1
    jm: '10.130.0.141',        // http://localhost:8080/#/main/?ip=2
};
// const ipAdd = '171.221.214.117'
// const ipAdd = '171.221.225.163'; // 外网
// const ipAdd = '10.0.200.100' // 青白江
// const ipAdd = '10.130.0.141' // 金贸
export const port = '8001';
export const userName = '1212';
export const passWord = 'Jwwl123456';
// 如果没有图片，也没有监控ID,就随机选一个监控ID,监控id写死了的。
export const monitorVideoID  = [6,7,8,9,95,374,375];
