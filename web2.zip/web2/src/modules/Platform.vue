<template>
    <div id="platform">
        <div id="content" class="fl">
            <router-view/>
        </div>
    </div>
</template>
<script>
    import VuePerfectScrollbar from 'vue-perfect-scrollbar';

    export default {
        name: "Platform",
        components: {VuePerfectScrollbar},
        provide () {
            return {
                reload: this.reload
            }
        },
        data() {
            return {
                isRouterAlive: true
            };
        },
        methods: {},
        watch: {},
        mounted() {

        }

    };
</script>
<style lang="scss">

</style>
<style lang="scss" scoped>
    .fl {
        float: left;
    }

    .fr {
        float: right;
    }
    @font-face {
        font-family: 'Quartz-Regular';
        src: url('../assets/font/Quartz-Regular.ttf');
        font-weight: normal;
        font-style: normal;
    }
    #platform, #content {
        width: 100%;
        height: 100%;

    }
</style>

