<template>
    <div class="video_component">
        <div class="video_box" ref='name'>
            <object classid="clsid:AC036352-03EB-4399-9DD0-602AB1D8B6B9" :id="PreviewOcx" width="840" height="540"
                    name="ocx"></object>
        </div>
        <div class="make" v-show="make" @click="vanish"></div>
    </div>
</template>
<script>
    import * as HostConfig from '../../../config'
    export default {
        props: {
            currentIndex: { // 当前显示第几个
                type: String,
                default() {
                    return '1'
                }
            }
        },
        data() {
            return {
                videoId: null,
                make: false,
                PreviewOcx: 'PreviewOcx' + this.currentIndex,
                flag: true,
                timer: null,
                config: {} // 当前配置项，对于config.js文件
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.$root.$on(`toogle_video_cover_${this.currentIndex}`, (isOpen) => { // 遮罩层
                    this.make = isOpen
                })
            });
            this.$root.$on(`video_box_big_${this.currentIndex}`, () => { // 放大
                this.big()
            });
            this.$root.$on(`video_box_smail_${this.currentIndex}`, () => { // 缩小
                this.smail()
            });
            this.$root.$on(`video_box_refresh_${this.currentIndex}`, () => { // 刷新
                this.startPlay('PreviewOcx' + this.currentIndex, this.videoId)
            });
            this.big();
            this.timer = setTimeout(() => { // 登录
                this.loginCms('PreviewOcx' + this.currentIndex, this.videoId)
            }, 5000);

        },
        methods: {
            currentVideoId(id, config) {
                this.videoId = id;
                this.config = config;
                console.log(this.config, '12')
            },
            big() {
                this.$refs.name.className = 'video_box1';
                this.$refs.name.childNodes[0].width = 850;
                this.$refs.name.childNodes[0].height = 540;
            },
            smail() {
                this.$refs.name.className = 'video_box';
                this.$refs.name.childNodes[0].height = 217;
                this.$refs.name.childNodes[0].width = 214
            },
            loginCms(id, index) {
                const OCXobj = document.getElementById(id);
                OCXobj.SetWndNum(1);
                let ipAdd = HostConfig.IP.public; // 外网
                let port = HostConfig.port; // 默认端口
                let userName = HostConfig.userName; // 用户名
                let passWord = HostConfig.passWord; // 密码
                // http://localhost:8080/#/main?ip=1&port=8001&userName=1212&passWord=123456
                /**************** ip配置 */
                const isOk = Object.keys(this.config);
                if (!this.config.ip || isOk.length === 0) {
                    ipAdd = HostConfig.IP.public
                } else if (this.config.ip === "1") {
                    ipAdd = HostConfig.IP.qbj
                } else if (this.config.ip === "2") {
                    ipAdd = HostConfig.IP.jm
                } else {
                    ipAdd = this.config.ip
                }
                /**************** 端口配置 */
                if (!this.config.port) {
                    port = HostConfig.port;
                } else {
                    port = this.config.port
                }
                /**************** 用户配置 */
                if (!this.config.userName) {
                    userName = HostConfig.userName;
                } else {
                    userName = this.config.userName
                }
                /**************** 密码配置 */
                if (!this.config.passWord) {
                    passWord = HostConfig.passWord;
                } else {
                    passWord = this.config.passWord
                }
                const ret = OCXobj.Login(ipAdd, port, userName, passWord);
                switch (ret) {
                    case 0:
                        this.startPlay(id, index);
                        break
                    case -1:
                        if (OCXobj.GetLastError() == -1) {
                            alert("网络延迟，请刷新页面！~");
                        } else {
                            alert(OCXobj.GetLastError());
                        }
                        break
                    default:
                        break
                }
            },
            startPlay(id, index) {
                const OCXobj = document.getElementById(id);
                OCXobj.SetInitStreamType(2)
                const ret = OCXobj.StartTask_Preview(index);
                switch (ret) {
                    case 0:
                        break
                    case -1:
                        alert(OCXobj.GetLastError());
                        break
                    default:
                        break
                }
            },
            vanish() { // 点击遮罩层缩小
                this.$root.$emit(`toogle_video_cover_${this.currentIndex}`, false);
                this.$root.$emit(`video_box_smail_${this.currentIndex}`)
            }
        },
        watch: {
            index(a) {
                console.log(a)
            }
        },
        beforeDestroy() {
            this.timer && clearTimeout(this.timer)
        }
    }
</script>
<style scoped lang="scss" type="text/scss">
    .make {
        width: 100%;
        height: 100%;
        background: #000;
        opacity: .8;
        position: fixed;
        left: 0;
        top: 0;
        z-index: 999999;
    }

    .video_component {
        // width: 214px;
        // margin: auto;
        position: relative;
        height: 490px;
        overflow: hidden!important;
    }
    .video_box {
        position: absolute;
        left: 0;
        top: 0;
        z-index: 9999;
    }
    .loading {
        position: absolute;
        left: 47px;
        top: 0;
        z-index: 9900;
        width: 880px;
        height: 540px;
        background-color: red;
    }

    .video_box {
        width: 214px;
        height: 165px;
        overflow: hidden;
    }

    .Height {
        height: 0px !important;
    }

    .video_box1 {
        overflow: hidden;
        // width: 850px;
        // height: 490px;
        // overflow: hidden;
        // position: fixed;
        // left: 50%;
        // top: 50%;
        // transform: translate(-50%, -50%);
        // z-index: 999999;
    }
</style>

