<template>
    <div id="header">
        <div class="fl">
        </div>
        <div class="fl">
            <img src="../../../assets/img/title.png" alt="加载失败">
        </div>
        <div class="fl">
            <div class="fr">
                <p>{{date}}</p>
                <p>{{week}}</p>
            </div>
            <div class="fr">
                <p>{{time}}</p>
            </div>
        </div>
    </div>
</template>
<script>
    const weeks = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    import moment from 'moment';
    export default {
        data() {
          return {
              timer: null,
              time: null,
              date: null,
              week: null,
          }
        },
        mounted() {
            this.timer = setInterval(() => {
                const M = moment(); // 当前时间对象
                this.time = M.format('HH:mm:ss');
                this.date = M.format('YYYY/MM/DD');
                let indexString = M.format('d'); // 返回的是string
                this.week = weeks[Number(indexString)]; // 我们要显示汉子中文
            }, 1000);
        },
        beforeDestroy() {
            if (this.timer) {
                clearInterval(this.timer); // 在Vue实例销毁前，清除我们的定时器
            }
        }
    }
</script>
<style lang="scss">
    #header {
        background: url("../../../assets/img/header.png") no-repeat center;
        height: 74px;
        width: 1920px;
        margin-bottom: 25px;

        > div {
            width: 25%;
            height: 74px;

            &:nth-child(2) {
                width: 50%;
                text-align: center;
            }

            &:nth-child(3) {
                div {
                    padding-top: 5px;
                    margin-right: 40px;

                    &:nth-child(1) {
                        p {
                            font-size: 12px;
                            text-align: right;
                        }
                    }
                }
            }

            span {
                color: #39d6fe;
                font-size: 24px;
                margin-left: 35px;
            }

            p {
                color: #39d6fe;
                font-size: 24px;
            }
        }
    }
</style>
