<template>
    <div id="home">
        <CommonHeader />
        <div id="bigBox">
            <div class="header">
                <div><img src="../../assets/img/main/title1.png" alt="加载失败"></div>
            </div>
            <div class="content">
                <div class="left">
                    <div class="header"><img src="../../assets/img/main/title2.png" alt="加载失败"></div>
                    <div class="num">{{leftdata.creditIndex}}</div>
                    <div class="static">
                        <span class="fl">仓储</span>
                        <span class="fr">{{leftdata.storageIndex}} <span>分</span>  </span>
                    </div>
                    <div class="static">
                        <span class="fl">物流</span>
                        <span class="fr">{{leftdata.logisticsIndex}} <span>分</span>  </span>
                    </div>
                    <div class="static">
                        <span class="fl">存证</span>
                        <span class="fr">{{leftdata.certificateIndex}} <span>分</span>  </span>
                    </div>
                </div>
                <div class="middle">
                    <div class="header">
                        <div class="fl">
                            <span>类型</span>
                            <span>{{leftdata.type}}</span>
                        </div>
                        <div class="fl">
                            <span>数量</span>
                            <span>{{Number(leftdata.weight).toFixed(2) || '0.00'}}</span>
                            <span>吨</span>
                        </div>
                    </div>
                    <div class="heart">{{leftdata.assertsId}}</div>
                    <div class="second1">
                        <div class="second11" v-if="chainOption[0]"
                             @click="openTooltip(chainOption[0])">
                            <p class="hash">哈希值：{{chainOption[0].txHash}}</p>
                            <p>时间：{{chainOption[0].time}}</p>
                            <p class="details1" v-if="chainOption[0].resources[0]">详情：<span>{{chainOption[0].resources[0].resourceName}}</span>
                                <span>+{{chainOption[0].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption[0].resources[1]"><span>{{chainOption[0].resources[1].resourceName}}</span>
                                <span>+{{chainOption[0].resources[0].valuation}}</span></p>

                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption[0] && chainOption[0].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption[0].pictures && chainOption[0].pictures.length > 0">
                        </div>
                        <div class="second12" v-if="chainOption[1]"
                             @click="openTooltip(chainOption[1])">
                            <p class="hash">哈希值：{{chainOption[1].txHash}}</p>
                            <p>时间：{{chainOption[1].time}}</p>
                            <p class="details1" v-if="chainOption[1].resources[0]">详情：<span>{{chainOption[1].resources[0].resourceName}}</span>
                                <span>+{{chainOption[1].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption[1].resources[1]"><span>{{chainOption[1].resources[1].resourceName}}</span>
                                <span>+{{chainOption[1].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption[1] && chainOption[1].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption[1].pictures && chainOption[1].pictures.length > 0">
                        </div>
                        <div class="second13" v-if="chainOption[0]">
                            <div>入库</div>
                        </div>
                    </div>
                    <div class="second2">
                        <div class="second21" v-if="chainOption2[0]"
                             @click="openTooltip(chainOption2[0])">
                            <p class="hash">哈希值：{{chainOption2[0].txHash}}</p>
                            <p>时间：{{chainOption2[0].time}}</p>
                            <p class="details1" v-if="chainOption2[0].resources[0]">详情：<span>{{chainOption2[0].resources[0].resourceName}}</span>
                                <span>+{{chainOption2[0].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption2[0].resources[0]"><span>{{chainOption2[0].resources[1].resourceName}}</span>
                                <span>+{{chainOption2[0].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption2[0].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption2[0].pictures && chainOption2[0].pictures.length > 0">
                        </div>
                        <div class="second22" v-if="chainOption2[1]"
                             @click="openTooltip(chainOption2[1])">
                            <p class="hash">哈希值：{{chainOption2[1].txHash}}</p>
                            <p>时间：{{chainOption2[1].time}}</p>
                            <p class="details1" v-if="chainOption2[1].resources[0]">详情：<span>{{chainOption2[1].resources[0].resourceName}}</span>
                                <span>+{{chainOption2[1].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption2[1].resources[1]"><span>{{chainOption2[1].resources[1].resourceName}}</span>
                                <span>+{{chainOption2[1].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption2[1].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption2[1].pictures && chainOption2[1].pictures.length > 0">
                        </div>
                        <div class="second23" v-if="chainOption2[0]">
                            <div>加工</div>
                        </div>
                    </div>
                    <div class="second3">
                        <div class="second31" v-if="chainOption3[0]"
                             @click="openTooltip(chainOption3[0])">
                            <p class="hash">哈希值：{{chainOption3[0].txHash}}</p>
                            <p>时间：{{chainOption3[0].time}}</p>
                            <p class="details1" v-if="chainOption3[0].resources[0]">详情：<span>{{chainOption3[0].resources[0].resourceName}}</span>
                                <span>+{{chainOption3[0].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption3[0].resources[1]"><span>{{chainOption3[0].resources[1].resourceName}}</span>
                                <span>+{{chainOption3[0].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption3[0].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption3[0].pictures && chainOption3[0].pictures[0]">
                        </div>
                        <div class="second32" v-if="chainOption3[1]"
                             @click="openTooltip(chainOption3[1])">
                            <p class="hash">哈希值：{{chainOption3[1].txHash}}</p>
                            <p>时间：{{chainOption3[1].time}}</p>
                            <p class="details1" v-if="chainOption3[1].resources[0]">详情：<span>{{chainOption3[1].resources[0].resourceName}}</span>
                                <span>+{{chainOption3[1].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption3[1].resources[1]"><span>{{chainOption3[1].resources[1].resourceName}}</span>
                                <span>+{{chainOption3[1].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption3[1].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption3[1].pictures && chainOption3[1].pictures[0]">
                        </div>
                        <div class="second33" v-if="chainOption3[0]">
                            <div>出库</div>
                        </div>
                    </div>
                    <div class="second4">
                        <div class="second41" v-if="chainOption4[0]"
                             @click="openTooltip(chainOption4[0])">
                            <p class="hash">哈希值：{{chainOption4[0].txHash}}</p>
                            <p>时间：{{chainOption4[0].time}}</p>
                            <p class="details1" v-if="chainOption4[0].resources[0]">详情：<span>{{chainOption4[0].resources[0].resourceName}}</span>
                                <span>+{{chainOption4[0].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption4[0].resources[1]"><span>{{chainOption4[0].resources[1].resourceName}}</span>
                                <span>+{{chainOption4[0].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption4[0].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption4[0].pictures[0]">
                        </div>
                        <div class="second42" v-if="chainOption4[1]"
                             @click="openTooltip(chainOption4[1])">
                            <p class="hash">哈希值：{{chainOption4[1].txHash}}</p>
                            <p>时间：{{chainOption4[1].time}}</p>
                            <p class="details1" v-if="chainOption4[1].resources[0]">详情：<span>{{chainOption4[1].resources[0].resourceName}}</span>
                                <span>+{{chainOption4[1].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption4[1].resources[1]"><span>{{chainOption4[1].resources[1].resourceName}}</span>
                                <span>+{{chainOption4[1].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption4[1].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption4[1].pictures && chainOption4[1].pictures[0]">
                        </div>
                        <div class="second43" v-if="chainOption4[0]">
                            <div>盘点</div>
                        </div>
                    </div>
                    <div class="second5">
                        <div class="second51" v-if="chainOption5[0]"
                             @click="openTooltip(chainOption5[0])">
                            <p class="hash">哈希值：{{chainOption5[0].txHash}}</p>
                            <p>时间：{{chainOption5[0].time}}</p>
                            <p class="details1" v-if="chainOption5[0].resources[0]">详情：<span>{{chainOption5[0].resources[0].resourceName}}</span>
                                <span>+{{chainOption5[0].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption5[0].resources[1]"><span>{{chainOption5[0].resources[1].resourceName}}</span>
                                <span>+{{chainOption5[0].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption5[0].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption5[0].pictures && chainOption5[0].pictures[0]">
                        </div>
                        <div class="second52" v-if="chainOption5[1]"
                             @click="openTooltip(chainOption5[1])">
                            <p class="hash">哈希值：{{chainOption5[0].txHash}}</p>
                            <p>时间：{{chainOption5[0].time}}</p>
                            <p class="details1" v-if="chainOption5[1].resources[0]">详情：<span>{{chainOption5[1].resources[0].resourceName}}</span>
                                <span>+{{chainOption5[1].resources[0].valuation}}</span></p>
                            <p class="details2" v-if="chainOption5[1].resources[1]"><span>{{chainOption5[1].resources[1].resourceName}}</span>
                                <span>+{{chainOption5[1].resources[1].valuation}}</span></p>
                            <img src="../../assets/img/main/shipin.png" alt="加载失败" v-if="chainOption5[1].video">
                            <img src="../../assets/img/main/tupian.png" alt="加载失败" v-if="chainOption5[1].pictures && chainOption5[1].pictures[0]">
                        </div>
                        <div class="second53" v-if="chainOption5[0]">
                            <div style="height: 80px;line-height: 30px">物联<br/>芯片</div>
                        </div>
                    </div>
                </div>
                <div class="right">
                    <div class="header"><img src="../../assets/img/main/title3.png" alt="加载失败"></div>
                    <div class="rightSwiper">
                        <swiper :options="option" ref="mySwiper" style="width: 100%;height: 100%">
                            <template v-for="i in rightData">
                                <swiper-slide>
                                    <div class="rightOne">
                                        <span>{{i.resourceName}}</span>
                                        <span>+ {{i.valuation}}</span>
                                    </div>
                                </swiper-slide>
                            </template>
                        </swiper>
                    </div>
                </div>
            </div>
            <div class="footer">
                <img src="../../assets/img/main/arrowLeft.png" alt="加载失败" @click="goprev">
                <img src="../../assets/img/main/arrowRight.png" alt="加载失败" @click="gonext">
                <div>
                    <div v-for="(i,index) in allData" @click="gopage(index)" :class="{'current':step===index}"
                         :key="index">
                        <img :src="require('../../assets/img/main/step'+(index+1)+'.png')" alt="加载失败">
                        <div class="line" v-show="step>=index">
                            <img src="../../assets/img/main/dian2.png" alt="加载失败" v-show="step===index">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <el-dialog title="提示" :visible.sync="dialogVisible">
            <div class="pic">
                <img class="close" src="../../assets/img/main/close.png" alt="加载失败" @click="dialogVisible = false">
                <VuePerfectScrollbar v-scroll class="scrool" style="width: 100%;height: 85%;">
                    <IframeVideo v-if="videoUrl > 0 && dialogVisible" ref="detailDialog"></IframeVideo>
                    <img class="dis" alt="加载失败" v-if="picturesUrl && picturesUrl.length > 0" :key="k" v-for="(i, k) in picturesUrl" :src="i">
                </VuePerfectScrollbar>
            </div>
        </el-dialog>
    </div>
</template>
<script>
    const weeks = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    import VuePerfectScrollbar from 'vue-perfect-scrollbar';
    import {monitorVideoID} from '../../config'
    import IframeVideo from './IframeVideo';
    // import echarts from 'echarts';
    import {getAsserts} from '../.././api/getData';
    import {swiper, swiperSlide} from 'vue-awesome-swiper';
    import CommonHeader from './commonHeader';

    export default {
        name: "main",
        components: {
            VuePerfectScrollbar,
            swiper,
            swiperSlide,
            IframeVideo,
            CommonHeader
        },
        data() {
            return {
                dialogVisible: false,
                time: '',
                timer: '',
                timer2: null,
                date: '',
                week: '',
                step: 0,
                option: {
                    loop: false,
                    autoplay: true,
                    slidesPerView: 8,
                    stopOnLastSlide: true,
                    direction: 'vertical',//水平(horizontal)或垂直(vertical)。
                },
                page: {
                    size: 7,
                    page: 1
                },
                total: 0, // 总条数
                firstPrevPage: false, // 这个参数是判断我们在第一页如果触发请求上一页
                chainOption: [{
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }, {
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }],
                chainOption2: [{
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }, {
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }],
                chainOption3: [{
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }, {
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }],
                chainOption4: [{
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }, {
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }],
                chainOption5: [{
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }, {
                    pictures: '111',
                    resources: [{resourceName: "", valuation: ''}, {resourceName: "", valuation: ''}]
                }],
                rightData: [],
                leftdata: {
                    events: [{eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}]
                },
//                iframeUrl:'https://www.runoob.com/try/demo_source/mov_bbb.mp4',
//                iframeUrl: '',
                allData: [{events: []}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}],
                videoUrl: '',
                picturesUrl: '',
                timerDialog: null,
            };
        },
        methods: {
            async getAsserts() {
                let a = await getAsserts({params: this.page});
                this.total = a.data.totalElements || 0;
                /**
                 * 当前页数据不足7条，说明走到最后页了，我们请求第一页的部分数据
                 * @type {Array}
                 */
                // this.firstPrevPage 判断我们是请求上页还是下页的
                if (a.data.elements.length < 7 && a.data.totalElements > 7 && !this.firstPrevPage) {
                    const newD = await getAsserts({params: {size: 7 - a.data.elements.length, page: 1}});
                    if (newD.data) {
                        newD.data.elements.forEach(item => {
                            a.data.elements.push(item)
                        })
                    }
                }
                if (a.data.elements.length < 7 && a.data.totalElements > 7 && this.firstPrevPage) {
                    const newD = await getAsserts({params: {size: 7 - a.data.elements.length, page: this.page.page - 1}});
                    if (newD.data) {
                        newD.data.elements.forEach(item => {
                            a.data.elements.push(item)
                        })
                    }
                    this.firstPrevPage = false; // 完成后状态需要初始化。
                }
                this.chainOption = [];
                this.chainOption2 = [];
                this.chainOption3 = [];
                this.chainOption4 = [];
                this.chainOption5 = [];
                for (let i = 0; i < a.data.elements[this.step].events.length; i++) {
                    let data = a.data.elements[this.step].events[i];
                    // 没有图片和视频id就添加个公共id
                    if ((!data.pictures || data.pictures.length === 0) && (data.video === 0 || !data.video)) {
                        const videoArray = monitorVideoID;
                        data.video = videoArray[Math.floor((Math.random()*videoArray.length))]
                    }
                    if (data.eventName.indexOf("入库") !== -1) {
                        this.chainOption.push(data);
                    } else if (data.eventName.indexOf("加工") !== -1) {
                        this.chainOption2.push(data);
                    } else if (data.eventName.indexOf("出库") !== -1) {
                        this.chainOption3.push(data);
                    } else if (data.eventName.indexOf("盘点") !== -1) {
                        this.chainOption4.push(data);
                    } else if (data.eventName.indexOf("物联芯片") !== -1) {
                        this.chainOption5.push(data);
                    }
                }
                this.rightData = a.data.elements[this.step].assetDetailVos;
                this.leftdata = a.data.elements[this.step];
                this.allData = a.data.elements;
            },
            gopage(a) {
                if (this.timer2) {
                    clearInterval(this.timer2);
                }
                this.step = a;
                this.chainOption = [];
                this.chainOption2 = [];
                this.chainOption3 = [];
                for (let i = 0; i < this.allData[this.step].events.length; i++) {
                    let data = this.allData[this.step].events[i];
                    // 没有图片和视频id就添加个公共id
                    if ((!data.pictures || data.pictures.length=== 0)  && (data.video === 0 || !data.video)) {
                        const videoArray = monitorVideoID;
                        data.video = videoArray[Math.floor((Math.random()*videoArray.length))]
                    }
                    if (data.eventName.indexOf("入库") !== -1) {
                        this.chainOption.push(data);
                    } else if (data.eventName.indexOf("加工") !== -1) {
                        this.chainOption2.push(data);
                    } else if (data.eventName.indexOf("出库") !== -1) {
                        this.chainOption3.push(data);
                    } else if (data.eventName.indexOf("盘点") !== -1) {
                        this.chainOption4.push(data);
                    } else if (data.eventName.indexOf("物联芯片") !== -1) {
                        this.chainOption5.push(data);
                    }
                }
                this.rightData = this.allData[this.step].assetDetailVos;
                this.leftdata = this.allData[this.step];
                this.timer2 = setInterval(() => {
                    if (this.step < this.allData.length - 1) {
                        this.gopage(this.step + 1);
                    } else {
                        this.gopage(0);
                    }
                }, 15000);
            },
            gonext() { // 下一页
                // 已经在最后页了，再次点击我们就请求第一页数据
                if (this.page.page === Math.ceil(this.total / this.page.size)) {
                    this.page.page = 1;
                } else {
                    this.page.page += 1;
                }
                this.step = 0;
                this.getAsserts();
            },
            goprev() { // 上一页
                if (this.page.page <= 1) {
                    // 最后页向上取整
                    this.page.page = Math.ceil(this.total / this.page.size);
                    this.step = 0;
                    this.getAsserts();
                    this.firstPrevPage = true;
                } else {
                    this.page.page = this.page.page - 1;
                    this.step = 0;
                    this.getAsserts();
                }
            },
            openTooltip(data) {
                const {pictures,video} = data;
                if (pictures && pictures.length > 0) {
                    this.picturesUrl = pictures;
                    this.dialogVisible = true;
                    return
                }
                if ((!pictures || pictures.length === 0) && video > 0 ) {
                    this.videoUrl = video;
                    this.dialogVisible = true;
                    this.timerDialog = setTimeout(() => {
                        // 传递视频id，跟动态路由当前配置项
                        this.$refs.detailDialog.currentVideoId(this.videoUrl, this.$route.query);
                    }, 20);
                    return
                }
            }
        },
        watch: {
            dialogVisible(val) {
                if (!val) {
                    this.picturesUrl = '';
                    this.videoUrl = '';
                    this.timerDialog && clearTimeout(this.timerDialog);
                }
            }
        },
        mounted() {
            this.getAsserts();
            this.timer2 = setInterval(() => {
                if (this.step < this.allData.length - 1) {
                    this.gopage(this.step + 1);
                } else {
                    this.gopage(0);
                }
            }, 15000);
        },
        beforeDestroy() {
            // if (this.timer) {
            //     clearInterval(this.timer); // 在Vue实例销毁前，清除我们的定时器
            // }
            this.timer2 && clearTimeout(this.timer2)
        }
    };
</script>
<style lang="scss">
    #home {
        .pic {
            background: url("../../assets/img/main/tooltip.png") no-repeat center rgba(255, 255, 255, 0);
            // height: 564px;
            // padding-top: 80px;
            width: 966px;
            height: 575px;
            padding-top: 70px;
            text-align: center;
            position: relative;
            .close {
                position: absolute;
                top: 25px;
                right: 50px;
                cursor: pointer;
            }

            .dis {
                width: 80%;
                margin: 0 auto 20px;
            }
        }

        .el-dialog__header {
            display: none;
        }

        .el-dialog__body {
            padding: 0;
            background: none;
        }

        .el-dialog {
            background: none;
        }
    }


</style>
<style lang="scss" scoped>
    #home {
        background: url("../../assets/img/back.png") no-repeat center;
        width: 1920px;
        height: 1080px;
        overflow: hidden;

        #bigBox {
            background: url("../../assets/img/main/bigBox.png") no-repeat center;
            width: 1881px;
            height: 964px;
            margin: 20px auto;

            > .header {
                background: url("../../assets/img/titleBox.png") no-repeat center;
                height: 43px;
                width: 100%;

                div {
                    width: 100%;
                    text-align: center;
                    line-height: 43px;

                    img {
                        vertical-align: middle;
                    }
                }
            }

            .content {
                background: url("../../assets/img/main/middleBox.png") no-repeat center;
                width: 1783px;
                height: 626px;
                margin-top: 20px;
                margin-left: 10px;
                padding: 28px;

                > .left {
                    float: left;
                    background: url("../../assets/img/main/leftBox.png") no-repeat center;
                    width: 276px;
                    height: 518px;
                    margin-left: 28px;

                    .header {
                        overflow: hidden;
                        text-align: center;

                        img {
                            vertical-align: middle;
                        }
                    }

                    .num {
                        background: url("../../assets/img/main/yuan.png") no-repeat center;
                        width: 172px;
                        height: 174px;
                        text-align: center;
                        line-height: 174px;
                        color: #f48e10;
                        font-size: 48px;
                        font-family: Quartz-Regular;
                        margin: 20px auto;
                    }

                    .static {
                        background: url("../../assets/img/main/numBox.png") no-repeat center;
                        width: 222px;
                        height: 65px;
                        margin: 20px auto;

                        span {
                            line-height: 65px;
                            color: #00caff;
                            padding: 0 5px;
                            font-size: 20px;

                            &:nth-child(2) {
                                font-family: Quartz-Regular;
                                font-size: 34px;
                                color: #00faa8;

                                span {
                                    color: #00faa8;
                                    font-size: 16px;
                                    padding: 0;
                                    padding-right: 15px;
                                }
                            }
                        }
                    }
                }

                > .right {
                    float: right;
                    background: url("../../assets/img/main/rightBox2.png") no-repeat center;
                    width: 277px;
                    height: 588px;

                    .header {
                        overflow: hidden;
                        text-align: center;

                        img {
                            vertical-align: middle;
                        }
                    }

                    .rightSwiper {
                        width: 235px;
                        height: 520px;
                        margin: 20px auto;

                        .rightOne {
                            span {
                                float: left;
                                color: #33e1fd;
                                font-size: 16px;
                                line-height: 65px;

                                &:nth-child(1) {
                                    display: inline-block;
                                    width: 185px;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: nowrap;
                                }

                                &:nth-child(2) {
                                    float: right;
                                    color: #00faa8;
                                }
                            }
                        }
                    }
                }

                .middle {
                    float: left;
                    background: url("../../assets/img/main/center.png") no-repeat bottom;
                    width: 1128px;
                    height: 100%;
                    padding-top: 10px;
                    margin-top: -28px;
                    margin-left: 40px;
                    position: relative;

                    .header {
                        background: url("../../assets/img/main/topBox.png") no-repeat center;
                        height: 90px;
                        width: 694px;
                        margin: -10px auto 0;

                        div {
                            width: 49%;
                            height: 26px;
                            border-right: 3px solid #3b77be;
                            font-size: 22px;
                            color: #4183cd;
                            margin-top: 33px;
                            text-align: right;

                            span {
                                color: #00faa8;
                                padding: 0 8px;
                                position: relative;
                                top: -16px;

                                &:nth-child(1) {
                                    color: #4183cd;
                                    margin-left: 10px;
                                }

                                &:nth-child(2) {
                                    font-size: 36px;
                                    font-family: Quartz-Regular;
                                    margin-right: 15px;
                                }

                                &:nth-child(3) {
                                    color: #00faa8;
                                }
                            }

                            &:nth-child(2) {
                                text-align: left;
                                margin-left: 0;
                                border-right: none;

                                span {
                                    &:nth-child(2) {
                                        top: -14px;
                                        margin-right: 0;
                                    }
                                }

                            }
                        }
                    }

                    .heart {
                        width: 120px;
                        height: 120px;
                        position: absolute;
                        top: 0;
                        bottom: 0;
                        right: 0;
                        left: 0;
                        margin: auto;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        line-height: 116px;
                        color: white;
                        font-size: 24px;
                    }

                    .second1 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 48px;
                        left: 0;

                        .second11, .second12 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                            }
                        }

                        .second11 {
                            background: url("../../assets/img/main/third11.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            margin-top: -28px;
                            position: relative;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 35%;
                            }
                        }

                        .second12 {
                            background: url("../../assets/img/main/third12.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            position: relative;
                            top: -40px;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 31%;
                            }
                        }

                        .second13 {
                            background: url("../../assets/img/main/second1.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 56px;
                            right: -7px;

                            div {
                                width: 115px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                            }
                        }
                    }

                    .second2 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 48px;
                        right: 0;

                        .second21, .second22 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                                margin-left: 95px;
                            }
                        }

                        .second21 {
                            background: url("../../assets/img/main/third21.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            margin-top: -28px;
                            position: absolute;
                            right: 0;
                            top: 0;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 35%;
                            }
                        }

                        .second22 {
                            background: url("../../assets/img/main/third22.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            position: absolute;
                            right: 0;
                            top: 98px;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 31%;
                            }
                        }

                        .second23 {
                            background: url("../../assets/img/main/second2.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 56px;
                            left: -7px;

                            div {
                                width: 115px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                position: absolute;
                                top: 0;
                                right: 0;
                            }
                        }
                    }

                    .second3 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 272px;
                        left: 0;

                        .second31, .second32 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                            }
                        }

                        .second31 {
                            background: url("../../assets/img/main/third31.png") no-repeat center;
                            width: 291px;
                            height: 104px;
                            margin-top: 40px;
                            position: relative;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 38%;
                            }
                        }

                        .second32 {
                            background: url("../../assets/img/main/third32.png") no-repeat center;
                            width: 298px;
                            height: 129px;
                            position: relative;
                            top: -30px;
                            padding-top: 25px;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 35%;
                            }
                        }

                        .second33 {
                            background: url("../../assets/img/main/second3.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 83px;
                            right: 11px;

                            div {
                                width: 120px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                padding-top: 11px;
                                padding-left: 10px;
                            }
                        }
                    }

                    .second4 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 272px;
                        right: 0;

                        .second41, .second42 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                                margin-left: 85px;
                            }
                        }

                        .second41 {
                            background: url("../../assets/img/main/third41.png") no-repeat center;
                            width: 291px;
                            height: 104px;
                            margin-top: 40px;
                            position: absolute;
                            top: 0;
                            right: 0;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 40%;
                            }
                        }

                        .second42 {
                            background: url("../../assets/img/main/third42.png") no-repeat center;
                            width: 298px;
                            height: 129px;
                            padding-top: 25px;
                            position: absolute;
                            top: 143px;
                            right: 0;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 38%;
                            }
                        }

                        .second43 {
                            background: url("../../assets/img/main/second4.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 83px;
                            left: 11px;

                            div {
                                width: 120px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                position: absolute;
                                right: 6px;
                                bottom: 0;
                            }
                        }
                    }

                    .second5 {
                        width: 640px;
                        height: 266px;
                        position: absolute;
                        top: 379px;
                        right: 0;
                        left: 0;
                        margin: auto;

                        .second51, .second52 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                            }
                        }

                        .second51 {
                            background: url("../../assets/img/main/third51.png") no-repeat center;
                            width: 262px;
                            height: 136px;
                            position: absolute;
                            top: 109px;
                            left: 7px;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 33%;
                            }
                        }

                        .second52 {
                            background: url("../../assets/img/main/third52.png") no-repeat center;
                            width: 262px;
                            height: 136px;
                            position: absolute;
                            top: 111px;
                            right: 8px;

                            p {
                                margin-left: 50px;
                            }

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 33%;
                            }
                        }

                        .second53 {
                            background: url("../../assets/img/main/second5.png") no-repeat center;
                            width: 115px;
                            height: 215px;
                            position: absolute;
                            right: 0;
                            left: 0;
                            margin: auto;
                            text-align: center;

                            div {
                                width: 115px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                position: absolute;
                                bottom: 0;
                            }
                        }
                    }

                }

            }

            .footer {
                background: url("../../assets/img/main/stepBox.png") no-repeat bottom;
                width: 1735px;
                height: 185px;
                margin: 0 auto;
                position: relative;

                > img {
                    position: absolute;
                    top: 65px;
                    cursor: pointer;

                    &:nth-child(1) {
                        left: -25px;
                    }

                    &:nth-child(2) {
                        right: -25px;
                    }
                }

                > div {
                    width: 80%;
                    height: 160px;
                    margin: 0 auto;

                    div {
                        float: left;
                        width: 14%;
                        height: 160px;
                        text-align: center;
                        background: url("../../assets/img/main/stepBottom.png") no-repeat center bottom;
                        cursor: pointer;
                        margin-right: 4px;
                        position: relative;

                        &:last-child {
                            margin-right: 0;
                        }

                        &:first-child {
                            .line {
                                width: 83px;
                            }
                        }

                        &:hover {
                            background: url("../../assets/img/main/stepBottom_.png") no-repeat center bottom;
                        }

                        &.current {
                            background: url("../../assets/img/main/stepBottom_.png") no-repeat center bottom;
                        }

                        .line {
                            border-top: 1px solid rgba(0, 150, 222, 1);
                            width: 200px;
                            position: absolute;
                            top: -1px;
                            right: 95px;
                            background: none;

                            img {
                                position: absolute;
                                top: -10px;
                                right: -9px;
                            }
                        }
                    }
                }
            }
        }
    }

    .hash {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        /*display: -webkit-box;*/
        /*-webkit-line-clamp: 2;*/
        /*-webkit-box-orient: vertical;*/
        width: 185px;
    }

    .details1 {
        height: 22px;
        margin-top: -5px;

        span {
            display: inline-block;

            &:nth-child(1) {
                width: 125px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                position: relative;
                top: 6px;
            }

            &:nth-child(2) {
                color: #00faa8;
            }
        }
    }

    .details2 {
        height: 22px;

        span {
            display: inline-block;

            &:nth-child(1) {
                width: 125px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                position: relative;
                top: 6px;
                margin-left: 41px;
            }

            &:nth-child(2) {
                color: #00faa8;
            }
        }
    }
</style>
