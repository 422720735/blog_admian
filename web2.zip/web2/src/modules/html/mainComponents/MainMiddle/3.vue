<template>
    <div class="middle">
        <div class="header">
            <div class="fl">
                <span>类型</span>
                <span>钢卷</span>
            </div>
            <div class="fl">
                <span>数量</span>
                <span>689.00</span>
                <span>吨</span>
            </div>
        </div>
        <!--一级目录-->
        <div class="baseInfo">
            <div class="heart absoluteCenter">XK001XK001</div>
            <div class="typeActive" :class="`typeActive2`"></div>
        </div>
        <div class="baseTopBorder"></div>
        <div class="baseCenterBorder"></div>
        <div class="baseBottomBorder"></div>
        <!--二级目录-->
        <div class="twoLevel">
            <img class="prev pointer" src="./prev.png"
                 :style="{visibility: `${baseOffsetY !== 0 ? 'visible' : 'hidden'}`}"
                 alt="加载失败" @click="basePrev">
            <div class="secondaryWarp">
                <ul class="secondaryList" :style="{transform: `translateY(${baseOffsetY}px)`}">
                    <li class="item">
                        <div>1</div>
                    </li>
                    <li class="item">
                        <div>2</div>
                    </li>
                    <li class="item">
                        <div>3</div>
                    </li>
                    <li class="item">
                        <div>4</div>
                    </li>
                    <li class="item">
                        <div>5</div>
                    </li>
                    <li class="item">
                        <div>6</div>
                    </li>
                    <li class="item">
                        <div>7</div>
                    </li>
                    <li class="item">
                        <div>8</div>
                    </li>
                </ul>
            </div>
            <img class="next pointer" src="./next.png"
                 :style="{visibility: `${showBaseNextArrow ? 'visible' : 'hidden'}`}"
                 alt="加载失败" @click="baseNext">
        </div>
        <!--三级目录-->
        <div class="threeLevel">
            <div class="threeContent">
                <div class="line">
                    <div class="b-oneLine"></div>
                    <div class="b-twoLine"></div>
                </div>
                <div class="threeSwipet">
                    <img class="prev pointer" src="./prev.png"
                         :style="{visibility: `${childOffsetY !== 0 ? 'visible' : 'hidden'}`}"
                         alt="加载失败" @click="childPrev">
                    <div ref="te" class="threeSwipetContent">
                        <ul class="swipetList" :style="{transform: `translateY(${childOffsetY}px)`}">
                            <li @click="prevOrNext($event, 0)">11223</li>
                            <li @click="prevOrNext($event, 0)">2</li>
                            <li @click="prevOrNext($event, 0)">3</li>
                            <li @click="prevOrNext($event, 0)">4</li>
                        </ul>
                    </div>
                    <img class="next pointer" src="./next.png"
                         :style="{visibility: `${showChildNextArrow ? 'visible' : 'hidden'}`}"
                         alt="加载失败" @click="childNext">
                </div>
            </div>


            <div class="threeContent">
                <div class="line">
                    <div class="b-oneLine"></div>
                    <div class="b-twoLine"></div>
                </div>
                <div class="threeSwipet">
                    <img class="prev pointer" src="./prev.png"
                         :style="{visibility: `${childOffsetY !== 0 ? 'visible' : 'hidden'}`}"
                         alt="加载失败" @click="childPrev">
                    <div class="threeSwipetContent">
                        <ul class="swipetList" :style="{transform: `translateY(${childOffsetY}px)`}">
                            <li @click="prevOrNext($event, 1)">11223</li>
                            <li @click="prevOrNext($event, 1)">2</li>
                            <li @click="prevOrNext($event, 1)">3</li>
                            <li @click="prevOrNext($event, 1)">4</li>
                        </ul>
                    </div>
                    <img class="next pointer" src="./next.png"
                         :style="{visibility: `${showChildNextArrow ? 'visible' : 'hidden'}`}"
                         alt="加载失败" @click="childNext">
                </div>
            </div>

            <div class="threeContent">
                <div class="line">
                    <div class="b-oneLine"></div>
                    <div class="b-twoLine"></div>
                </div>
                <div class="threeSwipet">
                    <img class="prev pointer" src="./prev.png"
                         :style="{visibility: `${childOffsetY !== 0 ? 'visible' : 'hidden'}`}"
                         alt="加载失败" @click="childPrev">
                    <div class="threeSwipetContent">
                        <ul class="swipetList" :style="{transform: `translateY(${childOffsetY}px)`}">
                            <li @click="prevOrNext($event, 2)">1</li>
                            <li @click="prevOrNext($event, 2)">2</li>
                            <li @click="prevOrNext($event, 2)">3</li>
                            <li @click="prevOrNext($event, 2)">4</li>
                        </ul>
                    </div>
                    <img class="next pointer" src="./next.png"
                         :style="{visibility: `${showChildNextArrow ? 'visible' : 'hidden'}`}"
                         alt="加载失败" @click="childNext">
                </div>
            </div>
        </div>
        <!--四级目录-->
        <div class="lastLevel">
            <div class="moreLine">
                <div class="fixedLine active1_prev" :class="layerYClassName === 'active1_prev' ? 'current': ''"></div>
                <div class="fixedLine active1_next" :class="layerYClassName === 'active1_next' ? 'current': ''"></div>
                <div class="fixedLine active2_prev" :class="layerYClassName === 'active2_prev' ? 'current': ''"></div>
                <div class="fixedLine active2_next" :class="layerYClassName === 'active2_next' ? 'current': ''"></div>
                <div class="fixedLine active3_prev" :class="layerYClassName === 'active3_prev' ? 'current': ''"></div>
                <div class="fixedLine active3_next" :class="layerYClassName === 'active3_next' ? 'current': ''"></div>
                <!--四条变化的线-->
                <div class="variableBorder one" :class="[layerYClassName]"></div>
                <div class="variableBorder two" :class="[layerYClassName]"></div>
                <div class="variableBorder three" :class="[layerYClassName]"></div>
                <div class="variableBorder four" :class="[layerYClassName]"></div>
            </div>
            <div class="moreContent">
                <img class="prev pointer" src="./prev.png"
                     :style="{visibility: `${moreOffsetY !== 0 ? 'visible' : 'hidden'}`}"
                     alt="加载失败" @click="morePrev">
                <div class="moreSwiper">
                    <ul class="moreInfoList" :style="{transform: `translateY(${moreOffsetY}px)`}">
                        <li>1</li>
                        <li>2</li>
                        <li>3</li>
                        <li>4</li>
                        <li>5</li>
                        <li>6</li>
                        <li>7</li>
                        <li>8</li>
                        <li>9</li>
                        <li>10</li>
                    </ul>
                </div>
                <img class="next pointer" src="./next.png"
                     :style="{visibility: `${showMoreNextArrow ? 'visible' : 'hidden'}`}"
                     alt="加载失败" @click="moreNext">
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "middle",
        data() {
            return {
                baseOffsetY: 0, // 基础
                childOffsetY: 0,
                moreOffsetY: 0,
                currentMoreLine: 'prev',
                currentItemIndex: 1,
                i: 8,
                c: 4,
                m: 10,
            }
        },
        computed: {
            showBaseNextArrow() {
                /**
                 * this.i 到时候传递数组长度
                 * */
                if (-(this.i - 3) * 175 === this.baseOffsetY) {
                    return false
                }
                return true
            },
            showChildNextArrow() {
                /**
                 * this.i 到时候传递数组长度
                 * */
                if (-(this.c - 2) * 58 === this.childOffsetY) {
                    return false
                }
                return true
            },
            showMoreNextArrow() {
                /**
                 * this.i 到时候传递数组长度
                 * */
                if (-(this.m - 4) * 124 === this.moreOffsetY) {
                    return false
                }
                return true
            },
            layerYClassName() {
                return `active${this.currentItemIndex}_${this.currentMoreLine}`
            }
        },
        methods: {
            basePrev() {
                this.baseOffsetY += 175
            },
            baseNext() {
                this.baseOffsetY -= 175
            },
            childPrev() {
                this.childOffsetY += 58
            },
            childNext() {
                this.childOffsetY -= 58
            },
            morePrev() {
                this.moreOffsetY += 124
            },
            moreNext() {
                this.moreOffsetY -= 124
            },
            prevOrNext(e, index) {
                this.currentItemIndex = index + 1;
                if (e.layerY >= 0 && e.layerY <= 48) {
                    this.currentMoreLine = 'prev'
                } else {
                    this.currentMoreLine = 'next'
                }
            }
        }
    }
</script>
<style lang="scss" scoped>
    li {
        display: block;
    }
    .middle {
        float: left;
        /*background: url("../../assets/img/main/center.png") no-repeat bottom;*/
        width: 1128px;
        height: 100%;
        padding-top: 10px;
        margin-top: -28px;
        margin-left: 40px;
        position: relative;
        // 头部
        .header {
            background: url("./topBox.png") no-repeat center;
            height: 90px;
            width: 694px;
            margin: -10px auto 0;

            div {
                width: 49%;
                height: 26px;
                border-right: 3px solid #3b77be;
                font-size: 22px;
                color: #4183cd;
                margin-top: 33px;
                text-align: right;

                span {
                    color: #00faa8;
                    padding: 0 8px;
                    position: relative;
                    top: -16px;

                    &:nth-child(1) {
                        color: #4183cd;
                        margin-left: 10px;
                    }

                    &:nth-child(2) {
                        font-size: 36px;
                        font-family: Quartz-Regular;
                        margin-right: 15px;
                    }

                    &:nth-child(3) {
                        color: #00faa8;
                    }
                }

                &:nth-child(2) {
                    text-align: left;
                    margin-left: 0;
                    border-right: none;

                    span {
                        &:nth-child(2) {
                            top: -14px;
                            margin-right: 0;
                        }
                    }

                }
            }
        }

        // 一级目录
        .baseInfo {
            width: 150px;
            height: 150px;
            background-image: url("./base.png");
            position: absolute;
            left: 55px;
            top: 295px;

            .heart {
                /*position: absolute;*/
                /*top: 0;*/
                /*bottom: 0;*/
                /*right: 0;*/
                /*left: 0;*/
                /*margin: auto;*/
                text-align: center;
                /*line-height: 116px;*/
                color: white;
                font-size: 24px;
                z-index: 99;
                -moz-transform: translate(-50%, -50%);
                -ms-transform: translate(-50%, -50%);
                -webkit-transform: translate(-50%, -50%);
                transform: translate(-50%, -50%);
                -moz-transform: translate3d(-50%, -50%, 0);
                -webkit-transform: translate3d(-50%, -50%, 0);
                transform: translate3d(-50%, -50%, 0);
                /*overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;*/
            }

            .typeActive {
                width: 60px;
                height: 60px;
                position: absolute;
                margin: -30px 0 0 -30px;
                top: 50%;
                left: 50%;
                z-index: 88;
                background-repeat: no-repeat;
                background-position: center center;

                &.typeActive1 {
                    background-image: url("./type1.png");
                }

                &.typeActive2 {
                    background-image: url("./type2.png");
                }

                &.typeActive3 {
                    background-image: url("./type3.png");
                }

                &.typeActive4 {
                    background-image: url("./type4.png");
                }

                &.typeActive5 {
                    background-image: url("./type5.png");
                }

                &.typeActive6 {
                    background-image: url("./type6.png");
                }

                &.typeActive7 {
                    background-image: url("./type7.png");
                }
            }
        }

        // 一级线
        .baseTopBorder {
            width: 161px;
            height: 109px;
            position: absolute;
            top: 194px;
            left: 125px;
            background: url("./baseTopBorder.png") no-repeat;
        }

        .baseCenterBorder {
            width: 87px;
            height: 14px;
            position: absolute;
            top: 363px;
            left: 197px;
            background: url("./baseCenterBorder.png") no-repeat;
        }

        .baseBottomBorder {
            width: 161px;
            height: 110px;
            position: absolute;
            top: 437px;
            left: 123px;
            background: url("./baseBottomBorder.png") no-repeat;
        }

        .prevAndNext {
            width: 100%;
            height: 15px;
        }

        // 二级目录列表
        .twoLevel {
            position: absolute;
            left: 283px;
            top: 105px;
            width: 113px;

            img {
                margin: 0 auto;
                display: block;
            }

            .prev {
                margin-bottom: 16px;
            }

            .next {
                margin-top: 16px;
            }

            .secondaryWarp {
                height: 465px;
                overflow: hidden;

                .secondaryList {
                    font-size: 20px;
                    transition: all 0.8s;

                    .item {
                        color: #33e1fd;
                        margin-bottom: 60px;

                        div {
                            display: block;
                            width: 113px;
                            height: 115px;
                            line-height: 115px;
                            text-align: center;
                            background: url("./secondary.png") no-repeat;
                        }
                    }
                }
            }

        }

        // 三级目录
        .threeLevel {
            position: absolute;
            left: 389px;
            top: 0;
            // 三个版心
            .threeContent {
                position: relative;
                display: flex;

                .line {
                    .b-oneLine {
                        width: 122px;
                        height: 13px;
                        background: url("./oneLine.png") no-repeat;
                    }

                    .b-twoLine {
                        width: 122px;
                        height: 49px;
                        margin-top: 4px;
                        background: url("./twoLine.png") no-repeat;
                    }
                }

                .threeSwipet {
                    margin-top: -44px;
                    text-align: center;

                    .threeSwipetContent {
                        max-height: 116px;
                        margin-top: 10px;
                        overflow: hidden;

                        .swipetList {
                            transition: all 0.2s;

                            > li {
                                cursor: pointer;
                                width: 222px;
                                height: 48px;
                                line-height: 48px;
                                font-size: 14px;
                                background: url("./threeLevel.png") no-repeat;
                                color: #fbbe05;
                                margin-bottom: 10px;
                            }
                        }
                    }

                }

            }

            .threeContent:nth-of-type(1) {
                top: 174px;
            }

            .threeContent:nth-of-type(2) {
                top: 234px;
            }

            .threeContent:nth-of-type(3) {
                top: 294px;
            }
        }
    }
</style>
<style lang="scss" scoped>
    // 四级目录
    .lastLevel {
        position: relative;
        left: 726px;
        bottom: 0;
        text-align: center;
        display: flex;
        .moreLine {
            .fixedLine {
                position: relative;
                width: 0;
                height: 0;
                background: url("./basis.png") no-repeat;
                &.current {
                    width: 77px;
                    height: 14px;
                    transition: width ease .7s, height ease 0.7s;
                }
                &.active1_prev {
                    top: 84px;
                }
                &.active1_next {
                    top: 140px;
                }
                &.active2_prev {
                    top: 260px;
                }
                &.active2_next {
                    top: 316px;
                }

                &.active3_prev {
                    top: 434px;
                }
                &.active3_next {
                    top: 490px;
                }
            }
        }
        .moreContent {
            margin-left: 70px;
            margin-top: 5px;
            .moreSwiper {
                height: 504px;
                overflow: hidden;
                .moreInfoList {
                    padding-top: 14px;
                    margin-bottom: -6px;
                    transition: all 0.4s;

                    > li {
                        width: 220px;
                        height: 104px;
                        background: url("./moreInfo.png") no-repeat;
                        margin-bottom: 20px;
                    }
                }
            }
        }
    }
</style>
<style lang="scss" scoped>
    .variableBorder {
        position: relative;
        &.active1_prev {
            &.one {
                width: 72px;
                height: 1px;
                left: 77px;
                top: 75px;
                border-bottom: 1px solid #33e1fd;
            }
            &.two {
                transition: width ease .7s, height ease 0.7s;
                top: 74px;
                left: 127px;
                height: 125px;
                width: 20px;
                border-left:solid 1px #33e1fd;
                border-bottom: solid 1px #33e1fd;
            }
            &.three {
                transition: width ease .7s, height ease 0.7s;
                width: 47px;
                height: 250px;
                border-left:solid 1px #33e1fd;
                border-bottom: solid 1px #33e1fd;
                left: 100px;
                top: -52px;
            }
            &.four {
                height: 370px;
                top: -302px;
                left: 76px;
                width: 70px;
                border-left:solid 1px #33e1fd;
                border-bottom: solid 1px #33e1fd;
            }
        }
        &.active1_next {
            &.one {
                width: 72px;
                height: 1px;
                left: 76px;
                top: 74px;
                border-bottom: 1px solid #33e1fd;
            }
            &.two {
                top: 72px;
                left: 76px;
                height: 125px;
                width: 72px;
                /*border-left:solid 1px #33e1fd;*/
                border-bottom: solid 1px #33e1fd;
            }
            &.three {
                width: 72px;
                height: 250px;
                /*border-left:solid 1px #33e1fd;*/
                border-bottom: solid 1px #33e1fd;
                left: 76px;
                top: -56px;
            }
            &.four {
                height: 371px;
                top: -303px;
                left: 76px;
                width: 70px;
                border-left:solid 1px #33e1fd;
                border-bottom: solid 1px #33e1fd;
            }
        }

        &.active2_prev,&.active2_next,&.active3_prev,&.active3_next {
            &.one {
                width: 72px;
                height: 1px;
                left: 76px;
                top: 74px;
                border-bottom: 1px solid #33e1fd;
            }
            &.two {
                top: 72px;
                left: 76px;
                height: 125px;
                width: 72px;
                /*border-left:solid 1px #33e1fd;*/
                border-bottom: solid 1px #33e1fd;
            }
            &.three {
                width: 72px;
                height: 250px;
                /*border-left:solid 1px #33e1fd;*/
                border-bottom: solid 1px #33e1fd;
                left: 76px;
                top: -56px;
            }
            &.four {
                height: 371px;
                top: -303px;
                left: 76px;
                width: 70px;
                border-left:solid 1px #33e1fd;
                border-bottom: solid 1px #33e1fd;
            }
        }
        &.active3_next {
            &.four {
                height: 370px;
                top: -302px;
                left: 76px;
                width: 70px;
                border-left:solid 1px #33e1fd;
                border-bottom: solid 1px #33e1fd;
            }
        }
    }

</style>


