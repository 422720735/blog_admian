<template>
    <div class="footer">
        <img src="../../../assets/img/main/arrowLeft.png" alt="加载失败" @click="goprev">
        <img src="../../../assets/img/main/arrowRight.png" alt="加载失败" @click="gonext">
        <div class="footerContent">
            <swiper :options="option" ref="Fswiper">
                <template :options="option" v-for="(i,index) in allData">
                    <swiper-slide>
                        <div class="swiperItem">
                            <img :src="require('../../../assets/img/main/step'+((index)%7+1) +'.png')" alt="加载失败">
                        </div>
                    </swiper-slide>
                </template>
            </swiper>
        </div>
        <div class="line" >
            <img class="" src="../../../assets/img/main/dian2.png" alt="加载失败">
        </div>
    </div>
</template>

<script>
    import {swiper, swiperSlide} from 'vue-awesome-swiper';
    export default {
        props: {
            allData: {
                type: Array
            },
            currentpage: {
                type: Number,
                default() {
                    return 1
                }
            }
        },
        data() {
            const that = this;
            return {
                istrue: false,
                currentPage: 1,
                firstStatu: true, // 下一页数据
                option: {
                    speed: 100,
                    loop: false,
                    autoplay: true,
                    stopOnLastSlide: true,
                    slidesPerView: 7,
                    initialSlide: 0,
                    disableOnInteraction: false,
                    direction: 'horizontal',//水平(horizontal)或垂直(vertical)。
                    observer: true,
                    observeParents: false,
                    on: {
                        slideChangeTransitionEnd(data) {
                            that.swiperIndex = this.activeIndex;
                        }
                    },
                },
                step: 0,
                swiperIndex: 0,
                getNextStatu: false
            }
        },
        watch: {
            swiperIndex: {
                handler(newName, oldName) {
                    this.step = newName;
                    console.log(newName, oldName, this.allData.length);
                    this.$emit('currentSwiper', newName);
                    /***
                     * 走到1进行数据请求并进行缓存
                     */
                    if (newName === 1) {
                        // 走到1数据进行请求
                        this.$emit('nextPage', this.currentpage + 1);
                        //newName + 4 === this.blockData.length && newName === 4
                    } else if (newName === 7 && newName + 7 ===  this.allData.length && !this.getNextStatu) {
                        debugger
                        this.getNextStatu = true;
                        this.$emit('replacePage');
                        console.log(1)
                    } else if (newName === 14 && newName + 7 ===  this.allData.length) {
                        console.log(this.allData)
                        this.$emit('replacePage');
                        debugger
                    }
                },
                deep: true
            }
        },
        methods: {
            goprev() {},
            gonext() {},
            gopage() {},
            updateSwiper() {

                this.$refs.Fswiper.swiper.update();
                this.$refs.Fswiper.swiper.slideTo(0,0);
                this.$refs.Fswiper.swiper.autoplay.start();
            }
        },

        components: {
            swiper,
            swiperSlide,
        }
    }
</script>

<style lang="scss">
    .footer {
        background: url("../../../assets/img/main/stepBox.png") no-repeat bottom;
        width: 1735px;
        height: 185px;
        margin: 0 auto;
        position: relative;
        .line {
            border-top: 1px solid rgba(0, 150, 222, 1);
            width: 80px;
            position: absolute;
            top: -1px;
            left: 190px;
            background: none;

            img {
                   position: absolute;
                   z-index: 1200;
                   top: -10px;
                   right: -9px;
            }
        }
        > img {
            position: absolute;
            top: 65px;
            cursor: pointer;

            &:nth-child(1) {
                left: -25px;
            }

            &:nth-child(2) {
                right: -25px;
            }
        }

        .swiper-container {
            top: -12px;
            .swiper-wrapper {
                top: 12px;
            }
        }
        .footerContent {
            width: 80%;
            height: 160px;
            margin: 0 auto;
            position: relative;
            .swiperItem {
                /*float: left;*/
                /*width: 14%;*/
                position: relative;
                z-index: 70;
                height: 160px;
                text-align: center;
                margin-right: 4px;
                cursor: pointer;
                background: url("../../../assets/img/main/stepBottom.png") no-repeat center bottom;

            }
        }
    }
</style>
