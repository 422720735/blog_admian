<template>
    <div id="home">
        <CommonHeader />
        <div class="fl" style="width: 1481px">
            <div class="fl" style="width: 450px">
                <div id="leftTop" class="fl">
                    <div class="header">
                        <div><img src="../../assets/img/leftTopTitle.png" alt="加载失败"></div>
                    </div>
                    <div class="content">
                        <div class="fl" v-for="i in mData">
                            <p class="QR">{{i.count}}</p>
                            <p>{{i.name}}</p>
                        </div>
                    </div>
                </div>
                <div id="chainType" class="fl">
                    <div class="header">
                        <div><img src="../../assets/img/typeTitle.png" alt="加载失败"></div>
                    </div>
                    <div class="pieChart" ref="pieChart"></div>
                </div>
            </div>
            <div id="node" class="fl">
                <div class="header">
                    <div><img src="../../assets/img/nodeTitle.png" alt="加载失败"></div>
                </div>
                <div class="content">
                    <div v-for="(i,index) in nodeData" :key="index" :class="`${haveObj(i)}${currentType(nodeIndex, index)}`"></div>
                    <div class="toolTip" v-if="nodeData[nodeIndex]">
                        <div>
                            <div>
                                <p>节点类型</p>
                                <p>{{nodeData[nodeIndex].type}}</p>
                            </div>
                            <div>
                                <p>IP地址</p>
                                <p>{{nodeData[nodeIndex].ip}}</p>
                            </div>
                            <div>
                                <p>端口</p>
                                <p>{{nodeData[nodeIndex].port}}</p>
                            </div>
                            <div>
                                <p>服务器负载</p>
                                <p>{{nodeData[nodeIndex].load}}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="content2">
                    <div class="header">
                        <div><img src="../../assets/img/dynamicTitle.png" alt="加载失败"></div>
                    </div>
                    <div class="content" ref="barChart">

                    </div>
                </div>
            </div>
            <div id="chain" class="fl">
                <div class="header">
                    <div><img src="../../assets/img/chainTitle.png" alt="加载失败"></div>
                </div>
                <swiper :options="option" ref="mySwiper">
                    <template v-for="i in blockData">
                        <swiper-slide>
                            <div class="swiperOne">
                                <img src="../../assets/img/chain.png" alt="加载失败">
                                <img src="../../assets/img/chainLogo.png" alt="加载失败">
                                <div>
                                    <p>{{i.name}}</p>
                                    <p class="hash">哈希值：{{i.hashThisBlock}}</p>
                                    <p>生成时间：{{i.createTime | dateFormat}}</p>
                                </div>
                            </div>
                        </swiper-slide>
                    </template>
                </swiper>
            </div>
        </div>

        <div id="right" class="fl">
            <div class="header">
                <div><img src="../../assets/img/rightTitle.png" alt="加载失败"></div>
            </div>
            <div class="title">
                <p>资产总估值</p>
                <p>
                    <span v-if="SubsectionData.valuationTotal">{{Number(SubsectionData.valuationTotal / 10000).toFixed(2) || '0.00'}}</span>
                    <span v-else>{{'0.00'}}</span>
                    万元</p>
            </div>
            <div class="content" ref="rightFirst"></div>
            <div class="title">
                <p>资产总数量</p>
                <p>
                    <span v-if="SubsectionData.amountTotal">{{SubsectionData.amountTotal}}</span>
                    <span v-else>{{'0'}}</span>
                    个
                </p>
            </div>
            <div class="content" ref="rightSecond"></div>
            <div class="title">
                <p>资产总重量</p>
                <p>
                    <span
                        v-if="SubsectionData.weightTotal">{{Number(SubsectionData.weightTotal).toFixed(2) || '0.00'}}</span>
                    <span v-else>{{'0.00'}}</span>
                    吨</p>
            </div>
            <div class="content" ref="rightThird"></div>
        </div>

    </div>
</template>
<script>
    const maxCount = 6;
    const PageZide = 8;  // 分页每页显示8条
    const ShowCount = 4; // 轮播框显示的数量
    //  import VuePerfectScrollbar from 'vue-perfect-scrollbar';
    import echarts from 'echarts';
    import {deepCopy} from '../../deepCopy';
    import {getChain, getType, getDt, getNodes, getMaterials, getSubsection} from '../.././api/getData';
    import {swiper, swiperSlide} from 'vue-awesome-swiper';
    import CommonHeader from './commonHeader';
    export default {
        name: "Platform",
        components: {
            swiper,
            swiperSlide,
            CommonHeader
        },
        data() {
            const that = this;
            return {
                istrue: false,
                time: '',
                date: '',
                week: '',
                option: {
                    loop: false,
                    autoplay: true,
                    stopOnLastSlide: true,
                    slidesPerView: 4,
                    initialSlide: 0,
                    disableOnInteraction: false,
                    direction: 'horizontal',//水平(horizontal)或垂直(vertical)。
                    observer: true,
                    observeParents: false,
                    on: {
                        slideChangeTransitionEnd(data) {
                            that.swiperIndex = this.activeIndex;
                        }
                    },
                },
                chainData: [],
                DTdata: [],
                blockData: [],
                nodeData: [{}, {}, {}, {}, {}, {}],
                mData: [],
                SubsectionData: {},
                nodeIndex: 0,
                currentPage: 1,
                nextIndex: 1,
                swiperIndex: 0,
                swiperName: true,
                getNextStatu: true, // 下一页数据
                recordsData: null
            };
        },
        methods: {
            async init() {
                await this.cache();
                await this.replacePage();
            },
            ThisPieEcharts() {
                this.myChart = this.$echarts.init(this.$refs.pieChart);
                let echartData = [];
                let rich = {
                    yellow: {
                        fontSize: 22,
                        align: 'center',
                        padding: [40, 4, 3, 4]
                    },
                    total: {
                        fontSize: 22,
                        align: 'center',
                    },
                    white: {
                        color: "#fff",
                        align: 'center',
                        fontSize: 14,
                        padding: [0, 0],

                    },
                };
                this.option = {
                    title: {
                        text: '文件类型',
                        left: 'center',
                        top: '50%',
                        textStyle: {
                            color: '#fff',
                            fontSize: 18,
                            align: 'center'
                        }
                    },
                    series: [{
                        name: '',
                        type: 'pie',
                        radius: ['35%', '60%'],
                        center: ['50%', '55%'],
                        hoverAnimation: false,
                        color: ['#f9ae09', '#ebd310', '#7ff312', '#11f58e', '#0d8df7', '#028dff'],
                        label: {
                            normal: {
                                padding: [40, -40],
                                formatter: function (params, ticket, callback) {
                                    let total = 0; //考生总数量
                                    let percent = 0; //考生占比
                                    echartData.forEach(function (value, index, array) {
                                        total += value.value;
                                    });
                                    percent = ((params.value / total) * 100).toFixed(1);
                                    return '{white|' + params.name + '}\n{yellow|' + params.value + '份' + '}';
                                },
                                rich: rich
                            },
                        },
                        labelLine: {
                            normal: {
                                length: 20,
                                length2: 50,
                            }
                        },
                        data: echartData
                    }]
                };
                if (this.chainData) {
                    this.option.title.text = '文件类型';
                } else {
                    this.option.title.text = '';
                }
                for (let key in this.chainData) {
                    let name;
                    if (key === 'audio') name = '音频';
                    if (key === 'other') name = '其他';
                    if (key === 'picture') name = '图片';
                    if (key === 'rar') name = '压缩包';
                    if (key === 'text') name = '文本';
                    if (key === 'video') name = '视频';
                    if (parseInt(this.chainData[key]) > 0) {
                        echartData.push({
                            name: name,
                            value: this.chainData[key]
                        });
                    }
                }
                //  绘制图表
                this.myChart.setOption(this.option);
            },
            ThisBarEcharts() {
                this.myChart = this.$echarts.init(this.$refs.barChart);
                this.option = {
                    xAxis: {
                        data: ['涉恐人员', '涉稳人员', '涉毒人员', '在逃人员', '刑事犯罪\n前科、劣迹人员', '肇事肇祸\n精神病人', '重点上访人员'],
                        axisLine: {
                            lineStyle: {
                                color: '#0a156e'
                            }
                        },
                        axisLabel: {
                            color: '#6ecbf9',
                            fontSize: 14,
                            interval: 0
                        },
                        axisTick: {
                            show: false
                        }
                    },
                    yAxis: {
                        name: "笔",
                        minInterval: 1,
                        nameTextStyle: {
                            color: '#6ecbf9',
                            fontSize: 16
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#0a156e'
                            }
                        },
                        axisLabel: {
                            color: '#6ecbf9',
                            fontSize: 16
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            lineStyle: {
                                color: '#0a156e'
                            }
                        },
                    },
                    series: [{
                        type: 'bar',
                        barWidth: 32,
                        itemStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: '#01b4ff'
                                }, {
                                    offset: 0.8,
                                    color: '#0337ff'
                                }], false)
                            }
                        },
                        data: [222, 333, 222, 444, 222, 555, 111]
                    }]
                };
                this.option.xAxis.data = [];
                this.option.series[0].data = [];
                for (let i = 0; i < this.DTdata.length; i++) {
                    this.option.xAxis.data.push(this.DTdata[i].status);
                    this.option.series[0].data.push(this.DTdata[i].count);
                }
                //  绘制图表
                this.myChart.setOption(this.option);
            },
            RightBarEchartsFirst() {
                this.myChart = this.$echarts.init(this.$refs.rightFirst);
                this.option = {
                    grid: {
                        left: '4%',
                        right: '4%',
                        top: '16%',
                        bottom: '2%',
                        containLabel: true
                    },
                    xAxis: {
                        data: [10, 20, 30, 40, 50, 60, 70],
                        axisLine: {
                            lineStyle: {
                                color: '#3366ff'
                            }
                        },
                        axisLabel: {
                            color: 'white',
                            interval: 0
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    yAxis: {
                        name: "万元",
                        nameGap: '5',
                        nameTextStyle: {
                            fontSize: 16,
                            color: 'white'
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#3366ff'
                            }
                        },
                        axisLabel: {
                            color: 'white',
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    series: [{
                        type: 'bar',
                        barWidth: 18,
                        itemStyle: {
                            normal: {
//                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
//                                    offset: 0,
//                                    color: '#01b4ff'
//                                }, {
//                                    offset: 0.8,
//                                    color: '#0337ff'
//                                }], false)
                                color: function (params) {
                                    let colorList = [
                                        ['#01b4ff', '#0337ff'],
                                        ['#ef6e18', '#fcc204'],
                                    ];
                                    let index = 1;
                                    if (params.dataIndex > 4) {
                                        index = 0;
                                    }
                                    return new echarts.graphic.LinearGradient(0, 0, 0, 1,
                                        [{
                                            offset: 0,
                                            color: colorList[index][0]
                                        },
                                            {
                                                offset: 1,
                                                color: colorList[index][1]
                                            }
                                        ]);
                                }
                            }
                        },
                        data: [222, 333, 222, 444, 222, 666, 111],
                        markLine: {
                            name: 'aa',
                            data: [
                                [
                                    {
                                        name: '平均线',
                                        x: '50%',
                                        y: 155,
                                        symbol: 'none',
                                        lineStyle: {
                                            color: 'white'
                                        }
                                    },
                                    {
                                        x: '50%',
                                        y: 20,
                                        symbol: 'none',
                                        lineStyle: {
                                            color: 'white'
                                        }
                                    }
                                ]]
                        }
                    }]
                };
                this.option.xAxis.data = [];
                this.option.series[0].data = [];
                for (let i = 0; i < this.SubsectionData.valuations.length; i++) {
                    this.option.xAxis.data.push(this.SubsectionData.valuations[i].key);
                    this.option.series[0].data.push(this.SubsectionData.valuations[i].value / 10000);
                }
                //  绘制图表
                this.myChart.setOption(this.option);
            },
            RightBarEchartsSecond() {
                this.myChart = this.$echarts.init(this.$refs.rightSecond);
                this.option = {
                    grid: {
                        left: '4%',
                        right: '4%',
                        top: '16%',
                        bottom: '2%',
                        containLabel: true
                    },
                    xAxis: {
                        data: [10, 20, 30, 40, 50, 60, 70],
                        axisLine: {
                            lineStyle: {
                                color: '#3366ff'
                            }
                        },
                        axisLabel: {
                            color: 'white',
                            interval: 0
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    yAxis: {
                        name: "个",
                        nameGap: '5',
                        nameTextStyle: {
                            fontSize: 16,
                            color: 'white'
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#3366ff'
                            }
                        },
                        axisLabel: {
                            color: 'white',
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    series: [{
                        type: 'bar',
                        barWidth: 18,
                        itemStyle: {
                            normal: {
//                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
//                                    offset: 0,
//                                    color: '#01b4ff'
//                                }, {
//                                    offset: 0.8,
//                                    color: '#0337ff'
//                                }], false)
                                color: function (params) {
                                    let colorList = [
                                        ['#01b4ff', '#0337ff'],
                                        ['#ef6e18', '#fcc204'],
                                    ];
                                    let index = 1;
                                    if (params.dataIndex > 4) {
                                        index = 0;
                                    }
                                    return new echarts.graphic.LinearGradient(0, 0, 0, 1,
                                        [{
                                            offset: 0,
                                            color: colorList[index][0]
                                        },
                                            {
                                                offset: 1,
                                                color: colorList[index][1]
                                            }
                                        ]);
                                }
                            }
                        },
                        data: [222, 333, 222, 444, 222, 666, 111],
                        markLine: {
                            name: 'aa',
                            data: [
                                [
                                    {
                                        name: '平均线',
                                        x: '50%',
                                        y: 155,
                                        symbol: 'none',
                                        lineStyle: {
                                            color: 'white'
                                        }
                                    },
                                    {
                                        x: '50%',
                                        y: 20,
                                        symbol: 'none',
                                        lineStyle: {
                                            color: 'white'
                                        }
                                    }
                                ]]
                        }
                    }]
                };
                this.option.xAxis.data = [];
                this.option.series[0].data = [];
                for (let i = 0; i < this.SubsectionData.amounts.length; i++) {
                    this.option.xAxis.data.push(this.SubsectionData.amounts[i].key);
                    this.option.series[0].data.push(this.SubsectionData.amounts[i].value);
                }
                //  绘制图表
                this.myChart.setOption(this.option);
            },
            RightBarEchartsThird() {
                this.myChart = this.$echarts.init(this.$refs.rightThird);
                this.option = {
                    grid: {
                        left: '4%',
                        right: '4%',
                        top: '16%',
                        bottom: '2%',
                        containLabel: true
                    },
                    xAxis: {
                        data: [10, 20, 30, 40, 50, 60, 70],
                        axisLine: {
                            lineStyle: {
                                color: '#3366ff'
                            }
                        },
                        axisLabel: {
                            color: 'white',
                            interval: 0
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    yAxis: {
                        name: "吨",
                        nameGap: '5',
                        nameTextStyle: {
                            fontSize: 16,
                            color: 'white'
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#3366ff'
                            }
                        },
                        axisLabel: {
                            color: 'white',
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    series: [{
                        type: 'bar',
                        barWidth: 18,
                        itemStyle: {
                            normal: {
//                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
//                                    offset: 0,
//                                    color: '#01b4ff'
//                                }, {
//                                    offset: 0.8,
//                                    color: '#0337ff'
//                                }], false)
                                color: function (params) {
                                    let colorList = [
                                        ['#01b4ff', '#0337ff'],
                                        ['#ef6e18', '#fcc204'],
                                    ];
                                    let index = 1;
                                    if (params.dataIndex > 4) {
                                        index = 0;
                                    }
                                    return new echarts.graphic.LinearGradient(0, 0, 0, 1,
                                        [{
                                            offset: 0,
                                            color: colorList[index][0]
                                        },
                                            {
                                                offset: 1,
                                                color: colorList[index][1]
                                            }
                                        ]);
                                }
                            }
                        },
                        data: [222, 333, 222, 444, 222, 666, 111],
                        markLine: {
                            name: 'aa',
                            data: [
                                [
                                    {
                                        name: '平均线',
                                        x: '50%',
                                        y: 155,
                                        symbol: 'none',
                                        lineStyle: {
                                            color: 'white'
                                        }
                                    },
                                    {
                                        x: '50%',
                                        y: 20,
                                        symbol: 'none',
                                        lineStyle: {
                                            color: 'white'
                                        }
                                    }
                                ]]
                        }
                    }]
                };
                this.option.xAxis.data = [];
                this.option.series[0].data = [];
                for (let i = 0; i < this.SubsectionData.weights.length; i++) {
                    this.option.xAxis.data.push(this.SubsectionData.weights[i].key);
                    this.option.series[0].data.push(this.SubsectionData.weights[i].value);
                }
                //  绘制图表
                this.myChart.setOption(this.option);
            },
            async getType() {
                let a = await getType();
                this.chainData = a.data.data[0];
                this.ThisPieEcharts();
            },
            async getDt() {
                let a = await getDt();
                this.DTdata = a.data.data;
                this.ThisBarEcharts();
            },
            async getNodes() {
                let a = await getNodes();
                this.nodeData = [];
                for (let i = 0; i < maxCount; i++) {
                    if (a.data.data[i]) {
                        this.nodeData[i] = a.data.data[i]
                    } else {
                        this.nodeData[i] = {}
                    }
                }
                this.timer2 = setInterval(() => {
                    if (this.nodeIndex < a.data.data.length - 1) {
                        this.nodeIndex += 1;
                    } else {
                        this.nodeIndex = 0;
                    }
                }, 3000);
            },
            async getMaterials() {
                let a = await getMaterials();
                this.mData = a.data.data.splice(0, 10);
            },
            async getSubsection() {
                let a = await getSubsection();
                this.SubsectionData = a.data.data;
                this.RightBarEchartsFirst();
                this.RightBarEchartsSecond();
                this.RightBarEchartsThird();
            },
            haveObj(i) {
                if (Object.keys(i).length > 0) {
                    return 'have'
                }
                return 'no'
            },
            currentType(nodeIndex, index) {
                if (nodeIndex === index) {
                    return ' current'
                }
                return ''
            },
            async cache() { // 缓存下一页的数据
                this.recordsData = await getChain({
                    params: {
                        // speed: 1000,
                        page: this.currentPage,
                        size: PageZide,
                        direction: 'desc'
                    }
                });
            },
            async nextPage(nextPage) {
                this.page.page = nextPage;
                await this.cache();
            },
            async replacePage() {
                let response = this.recordsData.data.data.elements;
                let prev = [];

                if (this.currentPage > 1 && this.blockData.length > 0) { // 非第一页
                    /**
                     * 拷贝上一页的最后4条，我们需要在最新的数据前面进行添加，（这很重要，相当于原生轮播的拷贝一份innerHTML,这样才能实现无缝轮播）
                     * */
                    prev = deepCopy(this.blockData).slice(this.blockData.length - ShowCount , this.blockData.length);

                    for (let k = 0; k < prev.length; k++) {
                        this.blockData[k] = prev[k];
                    }

                    /**
                     * 拷贝后原来数据变成12条了，我们进行替换 4 - 12 这八条数据，页面始终保持8条数据 （现在数据变成 12条 0-11 0-3是我们拷贝的上面innerHTML，4-11是下一页数据位置，需要进行替换）
                     * */
                    for (let j = 0; j < response.length; j++) {
                        this.blockData[j + ShowCount] = response[j]
                    }
                    console.log(this.blockData.length)
                } else {
                    this.blockData = response;
                }

                this.$refs.mySwiper.swiper.update();

                this.$refs.mySwiper.swiper.slideTo(0,0);

                this.$refs.mySwiper.swiper.autoplay.start();
            }
        },
        watch: {
            swiperIndex: {
                handler(newName, oldName) {
                    console.log(newName)
                    /**
                     * 第一次是是 0 - 4跳转
                     * 第二次开始 走到5就先请求下次的数据进行缓存。到8的位置进行覆盖。
                     * 后续 0 -8 所以要加个判断值
                     */
                    if (newName === 1) {
                        this.currentPage + 1;
                        this.nextPage()
                    } else if (newName === 4) {
                        this.replacePage()
                    }

                    // if (!this.istrue && newName + 4 === this.blockData.length && newName === 4) {
                    //     this.currentPage += 1;
                    //     this.getChain();
                    //     this.istrue = true
                    // } else if (newName === 8 && this.blockData.length && !this.getNextStatu) { // 走到8就替换下一页数据
                    //     this.getNextStatu = true;
                    //     this.getChain();
                    // } else if (newName === 5 && this.blockData.length - 3 && this.getNextStatu) { // 走到5缓存下一页数据
                    //     this.getNextStatu = false;
                    //     this.currentPage += 1;
                    //     this.cache(); // 缓存数据
                    //     if (!this.recordsData || !this.recordsData.data || !this.recordsData.data.data || !this.recordsData.data.data.elements || this.recordsData.data.data.elements.length === 0) {
                    //         this.currentPage = 1;
                    //         this.cache() // 缓存数据
                    //     }
                    // }
                },
//                immediate: true,
                deep: true
            }
        },
        async mounted() {
            await this.init();
            await this.getType();
            await this.getDt();
            await this.getNodes();
            await this.getMaterials();
            await this.getSubsection();
//            this.timer = setInterval(() => {
//                let myDate = new Date();
//                let year = myDate.getFullYear();//获取年
//                let month = myDate.getMonth() + 1;//获取月，默认从0开始，所以要加一
//                let date = myDate.getDate();//获取日
//                let hours = myDate.getHours();//获取小时
//                let minutes = myDate.getMinutes();//获取分
//                let seconds = myDate.getSeconds();//获取秒
//                let weekend = myDate.getDay(); //获取星期几，这里获得到的是数字1-7，所以我下面自己new了一个数组把获取到的数字当下标
//                let weeks = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
//                let day = weeks[weekend];//这样就是显示的星期x了
//                //这些if判断是在小于10的时候前面自动补0
//                if (month < 10) {
//                    month = '0' + month;
//                }
//                if (date < 10) {
//                    date = '0' + date;
//                }
//                if (hours < 10) {
//                    hours = '0' + hours;
//                }
//                if (minutes < 10) {
//                    minutes = '0' + minutes;
//                }
//                if (seconds < 10) {
//                    seconds = '0' + seconds;
//                }
//                this.time = hours + ":" + minutes + ":" + seconds;
//                this.date = year + "/" + month + "/" + date;
//                this.week = day;
//
//            }, 1000);

        },
        beforeDestroy() {
            if (this.timer) {
                clearInterval(this.timer); // 在Vue实例销毁前，清除我们的定时器
            }
            if (this.timer2) {
                clearInterval(this.timer2); // 在Vue实例销毁前，清除我们的定时器
            }
        }
    };
</script>
<style lang="scss">
    #home {
        .swiper-container {
            clear: both;
            padding-right: 20px;
            padding-top: 20px;
        }
    }

</style>
<style lang="scss" scoped>
    #home {
        background: url("../../assets/img/back.png") no-repeat center;
        /*width: 100%;*/
        /*height: 100%;*/
        width: 1920px;
        height: 1080px;
        overflow: hidden;

        #header {
            background: url("../../assets/img/header.png") no-repeat center;
            height: 74px;
            width: 1920px;
            margin-bottom: 25px;

            > div {
                width: 25%;
                height: 74px;

                &:nth-child(2) {
                    width: 50%;
                    text-align: center;
                }

                &:nth-child(3) {
                    div {
                        padding-top: 5px;
                        margin-right: 40px;

                        &:nth-child(1) {
                            p {
                                font-size: 12px;
                                text-align: right;
                            }
                        }
                    }
                }

                span {
                    color: #39d6fe;
                    font-size: 24px;
                    margin-left: 35px;
                }

                p {
                    color: #39d6fe;
                    font-size: 24px;
                }
            }
        }

        #leftTop {
            background: url("../../assets/img/leftTopBox.png") no-repeat center;
            width: 430px;
            height: 408px;
            margin-left: 20px;
            overflow: hidden;

            .header {
                background: url("../../assets/img/titleBox.png") no-repeat center;
                height: 43px;
                width: 100%;

                div {
                    width: 100%;
                    text-align: center;
                    line-height: 43px;

                    img {
                        vertical-align: middle;
                    }
                }
            }

            .content {
                padding-top: 25px;
                margin: 0 25px;
                height: 360px;
                overflow: hidden;

                > div {
                    background: url("../../assets/img/gridding.png") no-repeat center;
                    width: 112px;
                    height: 98px;
                    margin-right: -23px;

                    &:nth-child(2n) {
                        margin-top: 55px;
                    }

                    &:nth-child(2n+5) {
                        margin-top: -45px;
                    }

                    &:nth-child(2n+6) {
                        margin-top: 10px;
                    }

                    &:nth-child(10) {
                        margin-top: -45px;
                        margin-left: 89px;
                    }

                    p {
                        width: 100%;
                        color: #00b8ec;
                        font-size: 14px;
                        font-weight: bold;
                        text-align: center;

                        &:nth-child(1) {
                            font-family: 'Quartz-Regular';
                            color: #00faa8;
                            font-size: 40px;
                            line-height: 50px;
                            font-weight: normal;
                            padding-top: 20px;
                        }
                    }
                }
            }
        }

        #node {
            background: url("../../assets/img/nodeBox.png") no-repeat center;
            width: 1011px;
            height: 755px;
            margin-left: 20px;

            .header {
                background: url("../../assets/img/titleBox.png") no-repeat center;
                height: 43px;
                width: 100%;

                div {
                    width: 100%;
                    text-align: center;
                    line-height: 43px;

                    img {
                        vertical-align: middle;
                    }
                }
            }

            .content {
                background: url("../../assets/img/circle.png") no-repeat center 150px;
                width: 100%;
                height: 340px;
                position: relative;

                >div.have {
                    background: url("../../assets/img/file.png") no-repeat center;
                }
                > div {
                    position: absolute;
                    width: 88px;
                    height: 75px;

                    cursor: pointer;

                    &:hover {
                        /*background: url("../../assets/img/file_.png") no-repeat center;*/
                    }

                    &.current {
                        background: url("../../assets/img/file_.png") no-repeat center;
                    }

                    &:nth-child(1) {
                        left: 298px;
                        top: 108px;

                        .toolTip {
                            background: url("../../assets/img/hoverLeft.png") no-repeat center;
                            top: -102px;
                            left: -117px;
                        }
                    }

                    &:nth-child(2) {
                        left: 552px;
                        top: 108px;

                        .toolTip {
                            background: url("../../assets/img/hover.png") no-repeat center;
                            top: -96px;
                            left: -386px;

                            > div {
                                float: left;

                                div {
                                    float: left;
                                }
                            }
                        }
                    }

                    &:nth-child(3) {
                        left: 838px;
                        top: 149px;

                        .toolTip {
                            background: url("../../assets/img/hover.png") no-repeat center;
                            top: -96px;
                            left: -386px;

                            > div {
                                float: left;

                                div {
                                    float: left;
                                }
                            }
                        }
                    }

                    &:nth-child(4) {
                        left: 623px;
                        top: 204px;

                        .toolTip {
                            background: url("../../assets/img/hover.png") no-repeat center;
                            top: -62px;
                            left: -396px;

                            > div {
                                float: left;

                                div {
                                    float: left;
                                }
                            }
                        }
                    }

                    &:nth-child(5) {
                        left: 368px;
                        top: 205px;

                        .toolTip {
                            background: url("../../assets/img/hoverLeft.png") no-repeat center;
                            top: -65px;
                            left: -103px;
                        }
                    }

                    &:nth-child(6) {
                        left: 91px;
                        top: 156px;

                        .toolTip {
                            background: url("../../assets/img/hoverLeft.png") no-repeat center;
                            top: -109px;
                            left: -90px;
                        }

                    }
                }

                .toolTip {
                    width: 594px;
                    height: 124px;
                    position: absolute;
                    left: 0;
                    right: 0;
                    margin: auto;
                    background: url("../../assets/img/hoverLeft.png") no-repeat center;

                    &:hover {
                        background: url("../../assets/img/hoverLeft.png") no-repeat center;
                    }

                    > div {
                        background: none;
                        float: right;
                        width: 480px;
                        padding-top: 25px;

                        div {
                            float: left;
                            width: 20%;
                            padding-top: 10px;

                            &:nth-child(2) {
                                width: 35%;
                            }

                            p {
                                color: #26befe;
                                font-size: 18px;
                                width: 100%;
                                text-align: center;

                                &:nth-child(2) {
                                    font-size: 22px;
                                    font-weight: bold;
                                    color: #0ef9b3;
                                    line-height: 30px;
                                }
                            }
                        }
                    }
                }

                /*display: none;*/
            }

            .content2 {
                background: url("../../assets/img/dynamicBox.png") no-repeat center;
                width: 100%;
                height: 345px;

                .content {
                    background: none;
                    width: 90%;
                    height: 290px;
                    margin: 0 auto;
                }

                /*display: none;*/
            }

            .donghua {
                width: 100%;
                height: 340px;
                transform: rotateX(-33.5deg);
                position: absolute;
                animation: myfirst 5s infinite;
                @keyframes myfirst {
                    0% {
                        transform: rotateZ(0deg)
                    }
                    100% {
                        transform: rotateZ(360deg)
                    }
                }
            }

            .donghua2 {
                > div {

                    @keyframes animX {
                        0% {
                            left: 90px;
                        }
                        100% {
                            left: 837px;
                        }
                    }
                    @keyframes animY {
                        0% {
                            top: 102px;
                        }
                        100% {
                            top: 204px;
                        }
                    }
                    @keyframes scale {

                        0% {
                            transform: scale(0.7)
                        }
                        50% {
                            transform: scale(1)
                        }
                        100% {
                            transform: scale(0.7)
                        }
                    }
                    //6个圆,x和y轴动画加起来是18s , 18/6 约等于3 每个球y轴 从0递减3,x轴与y差9/2s
                    &:nth-child(1) {
                        animation: animX 9s cubic-bezier(0.36, 0, 0.64, 1) -4.5s infinite alternate forwards,
                        animY 9s cubic-bezier(0.36, 0, 0.64, 1) 0s infinite alternate,
                    }

                    &:nth-child(2) {
                        animation: animX 9s cubic-bezier(0.36, 0, 0.64, 1) -7.5s infinite alternate forwards,
                        animY 9s cubic-bezier(0.36, 0, 0.64, 1) -3s infinite alternate,
                    }

                    &:nth-child(3) {
                        animation: animX 9s cubic-bezier(0.36, 0, 0.64, 1) -10.5s infinite alternate forwards,
                        animY 9s cubic-bezier(0.36, 0, 0.64, 1) -6s infinite alternate,
                    }

                    &:nth-child(4) {
                        animation: animX 9s cubic-bezier(0.36, 0, 0.64, 1) -13.5s infinite alternate forwards,
                        animY 9s cubic-bezier(0.36, 0, 0.64, 1) -9s infinite alternate,
                    }

                    &:nth-child(5) {
                        animation: animX 9s cubic-bezier(0.36, 0, 0.64, 1) -16.5s infinite alternate forwards,
                        animY 9s cubic-bezier(0.36, 0, 0.64, 1) -12s infinite alternate,
                    }

                    &:nth-child(6) {
                        animation: animX 9s cubic-bezier(0.36, 0, 0.64, 1) -19.5s infinite alternate forwards,
                        animY 9s cubic-bezier(0.36, 0, 0.64, 1) -15s infinite alternate,
                    }
                }
            }
        }

        #right {
            background: url("../../assets/img/rightBox.png") no-repeat center;
            width: 402px;
            height: 964px;
            margin-left: 20px;

            .header {
                background: url("../../assets/img/titleBox.png") no-repeat center;
                height: 43px;
                width: 100%;

                div {
                    width: 100%;
                    text-align: center;
                    line-height: 43px;

                    img {
                        vertical-align: middle;
                    }
                }
            }

            .title {
                background: url("../../assets/img/static.png") no-repeat center;
                width: 362px;
                height: 92px;
                margin: 35px auto 0;

                p {
                    font-size: 22px;
                    color: #00caff;

                    span {
                        font-family: 'Quartz-Regular';
                        font-size: 32px;
                        color: #00faa8;
                        margin-right: 5px;
                    }

                    &:nth-child(1) {
                        padding-top: 16px;
                        padding-left: 28px;
                    }

                    &:nth-child(2) {
                        font-size: 14px;
                        color: #00faa8;
                        text-align: right;
                        margin-top: -5px;
                        padding-right: 10px;
                    }
                }
            }

            .content {
                margin-top: 10px;
                height: 180px;
                margin-bottom: -20px;
            }
        }

        #chainType {
            background: url("../../assets/img/typeBox.png") no-repeat center;
            width: 430px;
            height: 329px;
            margin-left: 20px;
            margin-top: 20px;

            .header {
                background: url("../../assets/img/titleBox.png") no-repeat center;
                height: 43px;
                width: 100%;

                div {
                    width: 100%;
                    text-align: center;
                    line-height: 43px;

                    img {
                        vertical-align: middle;
                    }
                }
            }

            .pieChart {
                width: 100%;
                height: 280px;
            }
        }

        #chain {
            margin-top: 20px;
            background: url("../../assets/img/chainBox.png") no-repeat center;
            width: 1459px;
            height: 188px;
            margin-left: 20px;

            .header {
                background: url("../../assets/img/titleBox.png") no-repeat center;
                height: 43px;
                width: 100%;

                div {
                    width: 100%;
                    text-align: center;
                    line-height: 43px;

                    img {
                        vertical-align: middle;
                    }
                }
            }

            .swiperOne {
                background: url("../../assets/img/chainBorder.png") no-repeat right;
                height: 104px;
                width: 339px;
                padding-left: 20px;
                position: relative;

                img {
                    position: absolute;
                    top: 50px;
                    left: 0;

                    &:nth-child(2) {
                        top: 20px;
                        left: 50px;
                    }
                }

                div {
                    width: 240px;
                    padding-right: 10px;
                    height: 94px;
                    float: right;
                    padding-top: 15px;

                    p {
                        text-align: left;
                        color: white;
                        word-break: break-all;

                        &:nth-child(1) {
                            font-size: 18px;
                            font-weight: bold;
                        }
                    }
                }
            }
        }
    }

    .hash {
        overflow: hidden;
        text-overflow: ellipsis;
        /*white-space: nowrap;*/
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }
</style>
