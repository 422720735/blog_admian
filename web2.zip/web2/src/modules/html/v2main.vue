<template>
    <div id="home">
        <CommonHeader />
        <div id="bigBox">
            <div class="header">
                <div><img src="../../assets/img/main/title1.png" alt="加载失败"></div>
            </div>
            <div class="content">
                <div class="left">
                    <div class="header"><img src="../../assets/img/main/title2.png" alt="加载失败"></div>
                    <div class="num">{{leftdata.creditIndex}}</div>
                    <div class="static">
                        <span class="fl">仓储</span>
                        <span class="fr">{{leftdata.storageIndex}} <span>分</span>  </span>
                    </div>
                    <div class="static">
                        <span class="fl">物流</span>
                        <span class="fr">{{leftdata.logisticsIndex}} <span>分</span>  </span>
                    </div>
                    <div class="static">
                        <span class="fl">存证</span>
                        <span class="fr">{{leftdata.certificateIndex}} <span>分</span>  </span>
                    </div>
                </div>
                <div class="middle">
                    <div class="header">
                        <div class="fl">
                            <span>类型</span>
                            <span>{{allData[this.step].type}}</span>
                        </div>
                        <div class="fl">
                            <span>数量</span>
                            <span>{{Number(allData[this.step].weight).toFixed(2) || '0.00'}}</span>
                            <span>吨</span>
                        </div>
                    </div>
<!--                    <div class="heart">{{leftdata.assertsId}}</div>-->
                </div>
                <div class="right">
                    <div class="header"><img src="../../assets/img/main/title3.png" alt="加载失败"></div>
                    <div class="rightSwiper">
                        <swiper :options="option" ref="mySwiper" style="width: 100%;height: 100%">
                            <template v-for="i in rightData">
                                <swiper-slide>
                                    <div class="rightOne">
                                        <span>{{i.resourceName}}</span>
                                        <span>+ {{i.valuation}}</span>
                                    </div>
                                </swiper-slide>
                            </template>
                        </swiper>
                    </div>
                </div>
            </div>
            <footer-swper
                ref="footS"
                :currentpage="page.page"
                :allData="allData"
                @currentSwiper="currentSwiper"
                @nextPage="nextPage"
                @replacePage="replacePage"
            ></footer-swper>
        </div>
        <el-dialog title="提示" :visible.sync="dialogVisible">
            <div class="pic">
                <img class="close" src="../../assets/img/main/close.png" alt="加载失败" @click="dialogVisible = false">
                <VuePerfectScrollbar v-scroll class="scrool" style="width: 100%;height: 85%;">
                    <IframeVideo v-if="videoUrl > 0 && dialogVisible" ref="detailDialog"></IframeVideo>
                    <img class="dis" alt="加载失败" v-if="picturesUrl && picturesUrl.length > 0" :key="k" v-for="(i, k) in picturesUrl" :src="i">
                </VuePerfectScrollbar>
            </div>
        </el-dialog>
    </div>
</template>
<script>
    const PageZide = 14;  // 分页每页请求14条
    const ShowCount = 7; // 轮播框显示的数量
    const weeks = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    import VuePerfectScrollbar from 'vue-perfect-scrollbar';
    import {monitorVideoID} from '../../config'
    import IframeVideo from './IframeVideo';
    // import echarts from 'echarts';
    import {getAsserts} from '../.././api/getData';
    import {deepCopy} from '../../deepCopy';
    import {swiper, swiperSlide} from 'vue-awesome-swiper';
    import CommonHeader from './commonHeader';
    import FooterSwper from './mainComponents/swper.vue';

    export default {
        name: "main",
        components: {
            VuePerfectScrollbar,
            swiper,
            swiperSlide,
            IframeVideo,
            CommonHeader,
            FooterSwper
        },
        data() {
            return {
                dialogVisible: false,
                time: '',
                timer: '',
                timer2: null,
                date: '',
                week: '',
                step: 0,
                option: {
                    loop: false,
                    autoplay: true,
                    slidesPerView: 8,
                    stopOnLastSlide: true,
                    direction: 'vertical',//水平(horizontal)或垂直(vertical)。
                },
                page: {
                    size: 14,
                    page: 1
                },
                total: 0, // 总条数
                firstPrevPage: false, // 这个参数是判断我们在第一页如果触发请求上一页
                rightData: [],
                leftdata: {
                    events: [{eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}]
                },
                allData: [{events: []}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}, {eventName: ''}],
                videoUrl: '',
                picturesUrl: '',
                timerDialog: null,
                storage: null
            };
        },
        methods: {
            async init() {
                await this.cache();
                await this.replacePage();
            },
            currentSwiper(i) {
                this.step = i;
            },
            /***
             * 请求下一页的数据
             * @param nextPage 下页的页码
             * @returns {Promise<void>}
             */
            async nextPage(nextPage) {
                this.page.page = nextPage;
                await this.cache();
            },
            async replacePage() {
                debugger
                let prev = [];
                if (this.page.page > 1) { // 非第一页
                    /**
                     * 拷贝上一页的最后4条，我们需要在最新的数据前面进行添加，（这很重要，相当于原生轮播的拷贝一份innerHTML,这样才能实现无缝轮播）
                     * */
                    prev = deepCopy(this.allData).slice(this.allData.length - ShowCount , this.allData.length);
                    for (let k = 0; k < prev.length; k++) {
                        this.allData[k] = prev[k];
                        //this.allData.splice(k,0,prev[k]);
                    }
                    /**
                     * 拷贝后原来数据变成12条了，我们进行替换 4 - 12 这八条数据，页面始终保持8条数据 （现在数据变成 12条 0-11 0-3是我们拷贝的上面innerHTML，4-11是下一页数据位置，需要进行替换）
                     * */
                    for (let j = 0; j < this.storage.length; j++) {
                        this.allData[j + ShowCount] = this.storage[j]
                    }
                } else {
                    this.rightData = this.storage[this.step].assetDetailVos;
                    this.leftdata = this.storage[this.step];
                    this.allData = this.storage;
                }
                this.$refs.footS.updateSwiper();
            },
            /***
             * 我们轮播缓存下页的数据
             * @returns {Promise<void>}
             */
            async cache() {
                const response = await getAsserts({params: this.page});
                this.storage = response.data.elements;
                /**
                 * 判断最后页,补满7条
                 *
                 * */
                if (response.data.elements.length < this.page.page) {
                    const resultPage = this.page.page - response.data.elements.length;
                    console.log(resultPage, "rrrr")
                    const fill = await getAsserts({params: {page: this.page.page, size: resultPage }});
                    this.page.page = 0;
                    fill.forEach((item) => {
                        this.storage.push(item);
                    });
                }

            },
            async getAsserts() {
                const response = await getAsserts({params: this.page});
                this.rightData = response.data.elements[this.step].assetDetailVos;
                this.leftdata = response.data.elements[this.step];
                this.allData = response.data.elements;
            },
            gopage(a) {
                // if (this.timer2) {
                //     clearInterval(this.timer2);
                // }
                // this.step = a;
                // this.chainOption = [];
                // this.chainOption2 = [];
                // this.chainOption3 = [];
                // for (let i = 0; i < this.allData[this.step].events.length; i++) {
                //     let data = this.allData[this.step].events[i];
                //     // 没有图片和视频id就添加个公共id
                //     if ((!data.pictures || data.pictures.length=== 0)  && (data.video === 0 || !data.video)) {
                //         const videoArray = monitorVideoID;
                //         data.video = videoArray[Math.floor((Math.random()*videoArray.length))]
                //     }
                //     if (data.eventName.indexOf("入库") !== -1) {
                //         this.chainOption.push(data);
                //     } else if (data.eventName.indexOf("加工") !== -1) {
                //         this.chainOption2.push(data);
                //     } else if (data.eventName.indexOf("出库") !== -1) {
                //         this.chainOption3.push(data);
                //     } else if (data.eventName.indexOf("盘点") !== -1) {
                //         this.chainOption4.push(data);
                //     } else if (data.eventName.indexOf("物联芯片") !== -1) {
                //         this.chainOption5.push(data);
                //     }
                // }
                // this.rightData = this.allData[this.step].assetDetailVos;
                // this.leftdata = this.allData[this.step];
                // this.timer2 = setInterval(() => {
                //     if (this.step < this.allData.length - 1) {
                //         this.gopage(this.step + 1);
                //     } else {
                //         this.gopage(0);
                //     }
                // }, 15000);
            },
            gonext() { // 下一页
                // 已经在最后页了，再次点击我们就请求第一页数据
                // if (this.page.page === Math.ceil(this.total / this.page.size)) {
                //     this.page.page = 1;
                // } else {
                //     this.page.page += 1;
                // }
                // this.step = 0;
                // this.getAsserts();
            },
            goprev() { // 上一页
                // if (this.page.page <= 1) {
                //     // 最后页向上取整
                //     this.page.page = Math.ceil(this.total / this.page.size);
                //     this.step = 0;
                //     this.getAsserts();
                //     this.firstPrevPage = true;
                // } else {
                //     this.page.page = this.page.page - 1;
                //     this.step = 0;
                //     this.getAsserts();
                // }
            },
            openTooltip(data) {
                const {pictures,video} = data;
                if (pictures && pictures.length > 0) {
                    this.picturesUrl = pictures;
                    this.dialogVisible = true;
                    return
                }
                if ((!pictures || pictures.length === 0) && video > 0 ) {
                    this.videoUrl = video;
                    this.dialogVisible = true;
                    this.timerDialog = setTimeout(() => {
                        // 传递视频id，跟动态路由当前配置项
                        this.$refs.detailDialog.currentVideoId(this.videoUrl, this.$route.query);
                    }, 20);
                    return
                }
            }
        },
        watch: {
            dialogVisible(val) {
                if (!val) {
                    this.picturesUrl = '';
                    this.videoUrl = '';
                    this.timerDialog && clearTimeout(this.timerDialog);
                }
            }
        },
        mounted() {
            this.init();
            // this.getAsserts();

            // this.timer2 = setInterval(() => {
            //     if (this.step < this.allData.length - 1) {
            //         this.gopage(this.step + 1);
            //     } else {
            //         this.gopage(0);
            //     }
            // }, 15000);
        },
        beforeDestroy() {
            // if (this.timer) {
            //     clearInterval(this.timer); // 在Vue实例销毁前，清除我们的定时器
            // }
            this.timer2 && clearTimeout(this.timer2)
        }
    };
</script>
<style lang="scss">
    #home {
        .pic {
            background: url("../../assets/img/main/tooltip.png") no-repeat center rgba(255, 255, 255, 0);
            // height: 564px;
            // padding-top: 80px;
            width: 966px;
            height: 575px;
            padding-top: 70px;
            text-align: center;
            position: relative;
            .close {
                position: absolute;
                top: 25px;
                right: 50px;
                cursor: pointer;
            }

            .dis {
                width: 80%;
                margin: 0 auto 20px;
            }
        }

        .el-dialog__header {
            display: none;
        }

        .el-dialog__body {
            padding: 0;
            background: none;
        }

        .el-dialog {
            background: none;
        }
    }


</style>
<style lang="scss" scoped>
    #home {
        background: url("../../assets/img/back.png") no-repeat center;
        width: 1920px;
        height: 1080px;
        overflow: hidden;

        #bigBox {
            background: url("../../assets/img/main/bigBox.png") no-repeat center;
            width: 1881px;
            height: 964px;
            margin: 20px auto;

            > .header {
                background: url("../../assets/img/titleBox.png") no-repeat center;
                height: 43px;
                width: 100%;

                div {
                    width: 100%;
                    text-align: center;
                    line-height: 43px;

                    img {
                        vertical-align: middle;
                    }
                }
            }

            .content {
                background: url("../../assets/img/main/middleBox.png") no-repeat center;
                width: 1783px;
                height: 626px;
                margin-top: 20px;
                margin-left: 10px;
                padding: 28px;

                > .left {
                    float: left;
                    background: url("../../assets/img/main/leftBox.png") no-repeat center;
                    width: 276px;
                    height: 518px;
                    margin-left: 28px;

                    .header {
                        overflow: hidden;
                        text-align: center;

                        img {
                            vertical-align: middle;
                        }
                    }

                    .num {
                        background: url("../../assets/img/main/yuan.png") no-repeat center;
                        width: 172px;
                        height: 174px;
                        text-align: center;
                        line-height: 174px;
                        color: #f48e10;
                        font-size: 48px;
                        font-family: Quartz-Regular;
                        margin: 20px auto;
                    }

                    .static {
                        background: url("../../assets/img/main/numBox.png") no-repeat center;
                        width: 222px;
                        height: 65px;
                        margin: 20px auto;

                        span {
                            line-height: 65px;
                            color: #00caff;
                            padding: 0 5px;
                            font-size: 20px;

                            &:nth-child(2) {
                                font-family: Quartz-Regular;
                                font-size: 34px;
                                color: #00faa8;

                                span {
                                    color: #00faa8;
                                    font-size: 16px;
                                    padding: 0;
                                    padding-right: 15px;
                                }
                            }
                        }
                    }
                }

                > .right {
                    float: right;
                    background: url("../../assets/img/main/rightBox2.png") no-repeat center;
                    width: 277px;
                    height: 588px;

                    .header {
                        overflow: hidden;
                        text-align: center;

                        img {
                            vertical-align: middle;
                        }
                    }

                    .rightSwiper {
                        width: 235px;
                        height: 520px;
                        margin: 20px auto;

                        .rightOne {
                            span {
                                float: left;
                                color: #33e1fd;
                                font-size: 16px;
                                line-height: 65px;

                                &:nth-child(1) {
                                    display: inline-block;
                                    width: 185px;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: nowrap;
                                }

                                &:nth-child(2) {
                                    float: right;
                                    color: #00faa8;
                                }
                            }
                        }
                    }
                }

                .middle {
                    float: left;
                    background: url("../../assets/img/main/center.png") no-repeat bottom;
                    width: 1128px;
                    height: 100%;
                    padding-top: 10px;
                    margin-top: -28px;
                    margin-left: 40px;
                    position: relative;

                    .header {
                        background: url("../../assets/img/main/topBox.png") no-repeat center;
                        height: 90px;
                        width: 694px;
                        margin: -10px auto 0;

                        div {
                            width: 49%;
                            height: 26px;
                            border-right: 3px solid #3b77be;
                            font-size: 22px;
                            color: #4183cd;
                            margin-top: 33px;
                            text-align: right;

                            span {
                                color: #00faa8;
                                padding: 0 8px;
                                position: relative;
                                top: -16px;

                                &:nth-child(1) {
                                    color: #4183cd;
                                    margin-left: 10px;
                                }

                                &:nth-child(2) {
                                    font-size: 36px;
                                    font-family: Quartz-Regular;
                                    margin-right: 15px;
                                }

                                &:nth-child(3) {
                                    color: #00faa8;
                                }
                            }

                            &:nth-child(2) {
                                text-align: left;
                                margin-left: 0;
                                border-right: none;

                                span {
                                    &:nth-child(2) {
                                        top: -14px;
                                        margin-right: 0;
                                    }
                                }

                            }
                        }
                    }

                    .heart {
                        width: 120px;
                        height: 120px;
                        position: absolute;
                        top: 0;
                        bottom: 0;
                        right: 0;
                        left: 0;
                        margin: auto;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        line-height: 116px;
                        color: white;
                        font-size: 24px;
                    }

                    .second1 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 48px;
                        left: 0;

                        .second11, .second12 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                            }
                        }

                        .second11 {
                            background: url("../../assets/img/main/third11.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            margin-top: -28px;
                            position: relative;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 35%;
                            }
                        }

                        .second12 {
                            background: url("../../assets/img/main/third12.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            position: relative;
                            top: -40px;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 31%;
                            }
                        }

                        .second13 {
                            background: url("../../assets/img/main/second1.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 56px;
                            right: -7px;

                            div {
                                width: 115px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                            }
                        }
                    }

                    .second2 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 48px;
                        right: 0;

                        .second21, .second22 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                                margin-left: 95px;
                            }
                        }

                        .second21 {
                            background: url("../../assets/img/main/third21.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            margin-top: -28px;
                            position: absolute;
                            right: 0;
                            top: 0;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 35%;
                            }
                        }

                        .second22 {
                            background: url("../../assets/img/main/third22.png") no-repeat center;
                            width: 304px;
                            height: 130px;
                            position: absolute;
                            right: 0;
                            top: 98px;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 31%;
                            }
                        }

                        .second23 {
                            background: url("../../assets/img/main/second2.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 56px;
                            left: -7px;

                            div {
                                width: 115px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                position: absolute;
                                top: 0;
                                right: 0;
                            }
                        }
                    }

                    .second3 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 272px;
                        left: 0;

                        .second31, .second32 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                            }
                        }

                        .second31 {
                            background: url("../../assets/img/main/third31.png") no-repeat center;
                            width: 291px;
                            height: 104px;
                            margin-top: 40px;
                            position: relative;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 38%;
                            }
                        }

                        .second32 {
                            background: url("../../assets/img/main/third32.png") no-repeat center;
                            width: 298px;
                            height: 129px;
                            position: relative;
                            top: -30px;
                            padding-top: 25px;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 35%;
                            }
                        }

                        .second33 {
                            background: url("../../assets/img/main/second3.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 83px;
                            right: 11px;

                            div {
                                width: 120px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                padding-top: 11px;
                                padding-left: 10px;
                            }
                        }
                    }

                    .second4 {
                        width: 520px;
                        height: 266px;
                        position: absolute;
                        top: 272px;
                        right: 0;

                        .second41, .second42 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                                margin-left: 85px;
                            }
                        }

                        .second41 {
                            background: url("../../assets/img/main/third41.png") no-repeat center;
                            width: 291px;
                            height: 104px;
                            margin-top: 40px;
                            position: absolute;
                            top: 0;
                            right: 0;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 40%;
                            }
                        }

                        .second42 {
                            background: url("../../assets/img/main/third42.png") no-repeat center;
                            width: 298px;
                            height: 129px;
                            padding-top: 25px;
                            position: absolute;
                            top: 143px;
                            right: 0;

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 38%;
                            }
                        }

                        .second43 {
                            background: url("../../assets/img/main/second4.png") no-repeat center;
                            width: 239px;
                            height: 131px;
                            position: absolute;
                            bottom: 83px;
                            left: 11px;

                            div {
                                width: 120px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                position: absolute;
                                right: 6px;
                                bottom: 0;
                            }
                        }
                    }

                    .second5 {
                        width: 640px;
                        height: 266px;
                        position: absolute;
                        top: 379px;
                        right: 0;
                        left: 0;
                        margin: auto;

                        .second51, .second52 {
                            width: 205px;
                            height: 80px;
                            padding-top: 15px;
                            margin-bottom: 15px;
                            cursor: pointer;

                            p {
                                color: #33e1fd;
                                padding-left: 15px;
                                word-break: break-all;
                                line-height: 22px;
                            }
                        }

                        .second51 {
                            background: url("../../assets/img/main/third51.png") no-repeat center;
                            width: 262px;
                            height: 136px;
                            position: absolute;
                            top: 109px;
                            left: 7px;

                            > img {
                                position: absolute;
                                left: -12px;
                                top: 33%;
                            }
                        }

                        .second52 {
                            background: url("../../assets/img/main/third52.png") no-repeat center;
                            width: 262px;
                            height: 136px;
                            position: absolute;
                            top: 111px;
                            right: 8px;

                            p {
                                margin-left: 50px;
                            }

                            > img {
                                position: absolute;
                                right: -12px;
                                top: 33%;
                            }
                        }

                        .second53 {
                            background: url("../../assets/img/main/second5.png") no-repeat center;
                            width: 115px;
                            height: 215px;
                            position: absolute;
                            right: 0;
                            left: 0;
                            margin: auto;
                            text-align: center;

                            div {
                                width: 115px;
                                height: 120px;
                                color: #33e1fd;
                                font-size: 20px;
                                line-height: 120px;
                                text-align: center;
                                position: absolute;
                                bottom: 0;
                            }
                        }
                    }

                }

            }
        }
    }

    .hash {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        /*display: -webkit-box;*/
        /*-webkit-line-clamp: 2;*/
        /*-webkit-box-orient: vertical;*/
        width: 185px;
    }

    .details1 {
        height: 22px;
        margin-top: -5px;

        span {
            display: inline-block;

            &:nth-child(1) {
                width: 125px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                position: relative;
                top: 6px;
            }

            &:nth-child(2) {
                color: #00faa8;
            }
        }
    }

    .details2 {
        height: 22px;

        span {
            display: inline-block;

            &:nth-child(1) {
                width: 125px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                position: relative;
                top: 6px;
                margin-left: 41px;
            }

            &:nth-child(2) {
                color: #00faa8;
            }
        }
    }
</style>
