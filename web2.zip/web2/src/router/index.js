import Vue from 'vue'
import Router from 'vue-router';
import Platform from '../modules/Platform.vue';


Vue.use(Router);

export default new Router({
    routes: [
        // 重定向

        {
            path: '/',
            redirect: '/home'
        },
        // {
        //     path:'/login',
        //     name:'login',
        //     component: resolve => require(['../modules/login/login.vue'],resolve)
        // },
        // {
        //     path:'/register',
        //     name:'register',
        //     component: resolve => require(['../modules/register/register.vue'],resolve)
        // },
        // {
        //     path:'/home',
        //     name:'home',
        //     component: resolve => require(['../modules/home/home.vue'],resolve)
        // },
        {
            path: '/',
            name: 'platform',
            component: Platform,
            children: [
                {
                    path:'/home',
                    name:'home',
                    component: resolve => require(['../modules/html/home.vue'],resolve)
                },
                {
                    path:'/main',
                    name:'main',
                    component: resolve => require(['../modules/html/main.vue'],resolve)
                },
                {
                    path:'/test',
                    name:'test',
                    component: resolve => require(['../modules/html/test.vue'],resolve)
                },
                {
                    path:'/v2main',
                    name:'v2main',
                    component: resolve => require(['../modules/html/v2main2.vue'],resolve)
                }
            ]
        }
    ]
});
